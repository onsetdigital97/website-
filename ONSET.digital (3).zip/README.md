
  # ONSET.digital

  This is a code bundle for ONSET.digital. The original project is available at https://www.figma.com/design/PLgCVQIr5KP82h1vt36vkd/ONSET.digital.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  