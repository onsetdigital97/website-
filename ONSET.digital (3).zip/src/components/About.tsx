import { motion, useInView } from 'motion/react';
import { Sparkles, Target, Heart, Zap } from 'lucide-react';
import founderImage from 'figma:asset/eefb2601772c2bfe99fb9bc9f2f4131bce8f7bf8.png';
import { useRef } from 'react';

interface AboutProps {
  onNavigateHome: () => void;
}

interface TimelineItemProps {
  milestone: {
    phase: string;
    title: string;
    description: string;
  };
  index: number;
}

function TimelineItem({ milestone, index }: TimelineItemProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { 
    once: true, 
    margin: "-50px",
    amount: 0.5
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -30 }}
      animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
      transition={{ 
        duration: 0.7,
        delay: index * 0.15,
        ease: "easeOut"
      }}
      className="relative pl-8 border-l-2 border-[#C7AB6E]/30"
    >
      <motion.div 
        initial={{ scale: 0 }}
        animate={isInView ? { scale: 1 } : { scale: 0 }}
        transition={{ 
          duration: 0.4,
          delay: index * 0.15 + 0.2,
          ease: "easeOut"
        }}
        className="absolute -left-2 top-0 w-4 h-4 bg-[#C7AB6E] rounded-full"
      />
      <span className="text-[#C7AB6E] text-sm uppercase tracking-wider">{milestone.phase}</span>
      <h3 className="text-2xl text-white mt-2 mb-3">{milestone.title}</h3>
      <p className="text-white/70">{milestone.description}</p>
    </motion.div>
  );
}

export function About({ onNavigateHome }: AboutProps) {
  const timelineData = [
    {
      phase: "Der Anfang",
      title: "ONSET – Der Beginn",
      description: "ONSET bedeutet Beginn. Aus dieser Idee heraus wurde ONSET DIGITAL geboren: Als Startpunkt für Unternehmen, die den Sprung in die digitale Zukunft wagen wollen."
    },
    {
      phase: "Evolution",
      title: "Klassik trifft Innovation",
      description: "Wir haben erkannt, dass die besten Lösungen dort entstehen, wo bewährte Marketing-Strategien auf moderne Technologie treffen. Design und digitales Verständnis wurden zu unserer DNA."
    },
    {
      phase: "Heute",
      title: "Vision wird Realität",
      description: "Heute verbinden wir klassisches Marketing mit KI-gesteuerter Automatisierung. Wir sind die Brücke zwischen traditionellem Business und digitaler Zukunft."
    },
    {
      phase: "Morgen",
      title: "Der Beginn einer neuen Ära",
      description: "Unser Ziel: Jedem Unternehmen den perfekten Onset – den idealen Startpunkt – für ihre digitale Transformation zu ermöglichen."
    }
  ];

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section */}
      <main className="pt-32 pb-24">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full mb-6">
              <Sparkles className="w-4 h-4 text-[#C7AB6E]" />
              <span className="text-[#C7AB6E] text-sm">Über uns</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl text-white mb-6">
              Die Vision hinter
              <span className="text-[#C7AB6E]"> ONSET DIGITAL</span>
            </h1>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              Vision trifft Realität – Design und digitales Verständnis vereinen
            </p>
          </motion.div>

          {/* Founder Story Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mb-24"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <div className="space-y-6 lg:-mt-2">
                <h2 className="text-3xl md:text-5xl text-white leading-tight">
                  ONSET –
                  <span className="text-[#C7AB6E]"> Der Beginn Ihrer digitalen Zukunft</span>
                </h2>
                <div className="space-y-4 text-white/70 text-lg">
                  <p>
                    ONSET bedeutet Beginn – der Startpunkt für Unternehmen, die klassisches Marketing 
                    mit digitaler Zukunft verbinden. Als Gründerin von ONSET DIGITAL habe ich eine 
                    klare Vision: Design und digitales Verständnis zu vereinen.
                  </p>
                  <p>
                    Wir verbinden bewährte Marketing-Strategien mit KI-Automatisierung. Dort, wo 
                    traditionelle Ansätze auf Innovation treffen, entsteht echter Mehrwert – und 
                    die Brücke zwischen Heute und Morgen.
                  </p>
                </div>
                <div className="pt-4">
                  <p className="text-white text-xl">— Juliane Elmas</p>
                  <p className="text-[#C7AB6E]">Gründerin & CEO, ONSET DIGITAL</p>
                </div>
              </div>

              {/* Founder Image & Info */}
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-[#C7AB6E]/20 to-transparent rounded-3xl blur-3xl" />
                <div className="relative">
                  {/* Image */}
                  <div className="relative rounded-3xl overflow-hidden mb-6 border border-white/10">
                    <img 
                      src={founderImage} 
                      alt="Juliane Elmas - Gründerin & CEO von ONSET DIGITAL"
                      className="w-full h-auto object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  </div>
                  
                  {/* Info Cards */}
                  <div className="bg-gradient-to-br from-white/10 to-white/5 border border-white/10 rounded-3xl p-6 backdrop-blur-sm">
                    <div className="space-y-4">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-[#C7AB6E]/20 rounded-xl flex items-center justify-center flex-shrink-0">
                          <Target className="w-6 h-6 text-[#C7AB6E]" />
                        </div>
                        <div>
                          <h3 className="text-white text-lg">Unsere Mission</h3>
                          <p className="text-white/60">Klassisches Marketing mit Zukunft verbinden</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-[#C7AB6E]/20 rounded-xl flex items-center justify-center flex-shrink-0">
                          <Heart className="w-6 h-6 text-[#C7AB6E]" />
                        </div>
                        <div>
                          <h3 className="text-white text-lg">Unsere Werte</h3>
                          <p className="text-white/60">Exzellenz, Transparenz, Impact</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-[#C7AB6E]/20 rounded-xl flex items-center justify-center flex-shrink-0">
                          <Zap className="w-6 h-6 text-[#C7AB6E]" />
                        </div>
                        <div>
                          <h3 className="text-white text-lg">Unsere Vision</h3>
                          <p className="text-white/60">Design und digitales Verständnis vereinen</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Our Story Timeline */}
          <div className="mb-24">
            <motion.h2 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8 }}
              className="text-3xl md:text-5xl text-center text-white mb-12"
            >
              Unsere Reise
            </motion.h2>
            <div className="max-w-3xl mx-auto space-y-8">
              {timelineData.map((milestone, index) => (
                <TimelineItem key={index} milestone={milestone} index={index} />
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.6 }}
            className="mt-20 text-center"
          >
            <h2 className="text-3xl md:text-4xl text-white mb-6">
              Bereit, die Zukunft zu gestalten?
            </h2>
            <p className="text-xl text-white/70 mb-8 max-w-2xl mx-auto">
              Lassen Sie uns gemeinsam herausfinden, wie KI und Automatisierung Ihr Unternehmen transformieren können.
            </p>
            <a
              href="https://www.bedarfsanalyse.onsetdigital.de"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#C7AB6E] text-black px-8 py-4 rounded-xl hover:bg-[#d4b87a] transition-all"
            >
              Jetzt Bedarfsanalyse starten
              <Zap className="w-4 h-4" />
            </a>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
