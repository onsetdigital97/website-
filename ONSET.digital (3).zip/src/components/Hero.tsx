import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Sparkles, Award, Users, Zap } from 'lucide-react';
import { useState, useEffect } from 'react';

interface HeroProps {
  onNavigateToKIAudit?: () => void;
}

const rotatingWords = ['Wachstum', 'Erfolg', 'Innovation', 'Zukunft'];
const rotatingHighlights = ['KI', 'Design', 'Tech'];

export function Hero({ onNavigateToKIAudit }: HeroProps) {
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [currentHighlightIndex, setCurrentHighlightIndex] = useState(0);

  useEffect(() => {
    const wordInterval = setInterval(() => {
      setCurrentWordIndex((prev) => (prev + 1) % rotatingWords.length);
    }, 3000);

    return () => clearInterval(wordInterval);
  }, []);

  useEffect(() => {
    const highlightInterval = setInterval(() => {
      setCurrentHighlightIndex((prev) => (prev + 1) % rotatingHighlights.length);
    }, 2500);

    return () => clearInterval(highlightInterval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(rgba(199, 171, 110, 0.05) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(199, 171, 110, 0.05) 1px, transparent 1px)`,
          backgroundSize: '100px 100px',
        }} />
        
        {/* Animated particles */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-[#C7AB6E] rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}

        {/* Glow effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#C7AB6E]/10 rounded-full blur-[120px]" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-32 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full mb-8"
        >
          <Sparkles className="w-4 h-4 text-[#C7AB6E]" />
          <span className="text-[#C7AB6E] text-sm">Wir suchen Pilotenprojekte für unsere KI-Agenten</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl mb-8 tracking-tight max-w-5xl mx-auto"
        >
          <span className="text-white block mb-2">Wir automatisieren</span>
          
          <span className="text-white block">
            <span className="relative inline-block">
              {/* Invisible placeholder for longest word to maintain space */}
              <span className="invisible">Innovation</span>
              
              {/* Actual animated words */}
              <span className="absolute inset-0 flex items-center justify-center">
                <AnimatePresence mode="wait">
                  <motion.span
                    key={currentWordIndex}
                    initial={{ y: 20, opacity: 0, filter: 'blur(8px)' }}
                    animate={{ y: 0, opacity: 1, filter: 'blur(0px)' }}
                    exit={{ y: -20, opacity: 0, filter: 'blur(8px)' }}
                    transition={{ duration: 0.5 }}
                    className="inline-block"
                  >
                    <span className="relative inline-block">
                      <span className="absolute inset-0 bg-gradient-to-r from-[#C7AB6E] via-white to-[#C7AB6E] bg-clip-text text-transparent animate-shimmer bg-[length:200%_100%]">
                        {rotatingWords[currentWordIndex]}
                      </span>
                      <span className="relative bg-gradient-to-r from-[#C7AB6E] via-white to-[#C7AB6E] bg-clip-text text-transparent">
                        {rotatingWords[currentWordIndex]}
                      </span>
                    </span>
                  </motion.span>
                </AnimatePresence>
              </span>
            </span>
            {' '}– mit{' '}
            <span className="relative inline-block">
              {/* Invisible placeholder for longest highlight */}
              <span className="invisible">Design</span>
              
              {/* Actual animated highlights */}
              <span className="absolute inset-0 flex items-center justify-center">
                <AnimatePresence mode="wait">
                  <motion.span
                    key={currentHighlightIndex}
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 1.2, opacity: 0 }}
                    transition={{ duration: 0.4 }}
                    className="inline-block"
                  >
                    <span className="relative">
                      <span className="absolute inset-0 blur-xl bg-[#C7AB6E] opacity-50"></span>
                      <span className="relative text-[#C7AB6E] drop-shadow-[0_0_20px_rgba(199,171,110,0.8)]">
                        {rotatingHighlights[currentHighlightIndex]}
                      </span>
                    </span>
                  </motion.span>
                </AnimatePresence>
              </span>
            </span>
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-xl md:text-2xl text-white/70 max-w-3xl mx-auto mb-12"
        >
          Full Service Agency für AI-Automation, Branding & skalierbare digitale Systeme
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <motion.a
            href="https://www.bedarfsanalyse.onsetdigital.de"
            target="_blank"
            rel="noopener noreferrer"
            className="group px-8 py-4 bg-[#C7AB6E] text-black rounded-lg flex items-center gap-2 hover:bg-[#d4b87a] transition-colors"
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(199, 171, 110, 0.6)' }}
            whileTap={{ scale: 0.98 }}
          >
            Bedarfsanalyse starten
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </motion.a>

          <motion.a
            href="#clients"
            className="px-8 py-4 bg-white/5 text-white border border-white/10 rounded-lg hover:bg-white/10 transition-colors backdrop-blur-sm"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          >
            Unsere Kunden ansehen
          </motion.a>
        </motion.div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
        >
          <div className="text-center p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-[#C7AB6E]/10 rounded-xl mb-4">
              <Award className="w-6 h-6 text-[#C7AB6E]" />
            </div>
            <div className="text-3xl md:text-4xl text-white mb-2">100%</div>
            <div className="text-white/60">Kundenzufriedenheit</div>
          </div>
          
          <div className="text-center p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-[#C7AB6E]/10 rounded-xl mb-4">
              <Users className="w-6 h-6 text-[#C7AB6E]" />
            </div>
            <div className="text-3xl md:text-4xl text-white mb-2">50+</div>
            <div className="text-white/60">Erfolgreiche Projekte</div>
          </div>
          
          <div className="text-center p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-sm">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-[#C7AB6E]/10 rounded-xl mb-4">
              <Zap className="w-6 h-6 text-[#C7AB6E]" />
            </div>
            <div className="text-3xl md:text-4xl text-white mb-2">24/7</div>
            <div className="text-white/60">KI-Automatisierung</div>
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-12 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-2"
          >
            <div className="w-1.5 h-1.5 bg-[#C7AB6E] rounded-full" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
