import { motion } from 'motion/react';
import clientLogo1 from 'figma:asset/df2054ed3b700f688cdd0f1cebae63e64aa3bc83.png';
import clientLogo2 from 'figma:asset/601cbe3f39ad4ef08170d554d31fcba914d7152b.png';
import clientLogo3 from 'figma:asset/265a2f9dc6df80964d3e64a61cd7360ddd5c0892.png';
import clientLogo4 from 'figma:asset/b5824ee4212436d556885cefd64678ea0c94398d.png';
import clientLogo5 from 'figma:asset/b0d6d075d1acf62aab680612a51850f4e5ce97a1.png';
import clientLogo6 from 'figma:asset/2ab1fa8519589f2112ef9df135112842f2c4050e.png';
import clientLogo7 from 'figma:asset/a3e30663da5d5fddad0875f1cead99b2138e859f.png';
import clientLogo8 from 'figma:asset/02d22974d1cbda2a4655a91fff3dd22e668adf6e.png';

// Client logos
const clients = [
  { name: 'Client 1', logo: clientLogo1 },
  { name: 'Client 2', logo: clientLogo2 },
  { name: 'Client 3', logo: clientLogo3 },
  { name: 'Client 4', logo: clientLogo4 },
  { name: 'Client 5', logo: clientLogo5 },
  { name: 'Client 6', logo: clientLogo6 },
  { name: 'Client 7', logo: clientLogo7 },
  { name: 'Client 8', logo: clientLogo8 },
];

export function Clients() {
  return (
    <section id="clients" className="relative py-32 bg-black overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#C7AB6E]/5 to-transparent" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full text-[#C7AB6E] text-sm mb-6">
            Vertrauen von führenden Unternehmen
          </span>
          <h2 className="text-4xl md:text-6xl mb-6 text-white">
            Unsere Kunden
          </h2>
          <p className="text-xl text-white/70 max-w-3xl mx-auto">
            Wir arbeiten mit Unternehmen, die auf Wachstum, Design-Ästhetik, Technologie und Automatisierung setzen
          </p>
        </motion.div>

        {/* Logo Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {clients.map((client, index) => (
            <motion.div
              key={`${client.name}-${index}`}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center justify-center"
            >
              <motion.div
                whileHover={{ scale: 1.05, opacity: 1 }}
                className="relative group cursor-pointer w-full"
              >
                {/* Logo container */}
                <div className="flex items-center justify-center h-32 px-8 py-6 bg-white/[0.02] border border-white/5 rounded-lg backdrop-blur-sm group-hover:bg-white/[0.05] group-hover:border-[#C7AB6E]/20 transition-all duration-300">
                  <img 
                    src={client.logo} 
                    alt={client.name}
                    className="max-h-16 w-auto object-contain opacity-40 group-hover:opacity-70 transition-opacity duration-300 filter brightness-0 invert"
                  />
                </div>

                {/* Subtle glow on hover */}
                <div className="absolute inset-0 bg-[#C7AB6E]/0 group-hover:bg-[#C7AB6E]/5 rounded-lg blur-xl transition-all duration-300 -z-10" />
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Stats section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          <div className="text-center p-6 bg-white/[0.02] border border-white/5 rounded-xl backdrop-blur-sm">
            <div className="text-4xl text-[#C7AB6E] mb-2">50+</div>
            <p className="text-white/60">Erfolgreiche Projekte</p>
          </div>
          <div className="text-center p-6 bg-white/[0.02] border border-white/5 rounded-xl backdrop-blur-sm">
            <div className="text-4xl text-[#C7AB6E] mb-2">15+</div>
            <p className="text-white/60">Zufriedene Kunden</p>
          </div>
          <div className="text-center p-6 bg-white/[0.02] border border-white/5 rounded-xl backdrop-blur-sm">
            <div className="text-4xl text-[#C7AB6E] mb-2">100%</div>
            <p className="text-white/60">Kundenzufriedenheit</p>
          </div>
        </motion.div>

        {/* Optional: Animated scrolling logos */}
        <div className="mt-20 relative overflow-hidden">
          <div className="flex items-center gap-12 animate-scroll">
            {[...clients, ...clients].map((client, index) => (
              <div
                key={`scroll-${index}`}
                className="flex-shrink-0"
              >
                <img 
                  src={client.logo} 
                  alt={client.name}
                  className="h-8 w-auto object-contain opacity-20 filter brightness-0 invert"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .animate-scroll {
          animation: scroll 30s linear infinite;
        }
      `}</style>
    </section>
  );
}
