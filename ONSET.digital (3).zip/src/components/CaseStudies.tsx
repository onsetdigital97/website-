import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowUpRight, TrendingUp } from 'lucide-react';

const cases = [
  {
    title: 'E-Commerce Automation',
    client: 'Fashion Retailer',
    problem: 'Manuelle Bestellabwicklung und Kundenservice führten zu Verzögerungen und hohen Kosten',
    solution: 'KI-gesteuerte Automatisierung der gesamten Order-to-Cash-Prozesse inkl. Smart Chatbot',
    result: '85% Zeitersparnis, 3x schnellere Bearbeitung, 40% Kostensenkung',
    image: 'https://images.unsplash.com/photo-1758411898049-4de9588be514?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBkYXNoYm9hcmQlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzYxMTk4NjQ2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    tags: ['AI Automation', 'E-Commerce', 'JTL'],
  },
  {
    title: 'Marketing Performance Suite',
    client: 'SaaS Startup',
    problem: 'Ineffiziente Lead-Generierung und fehlende Skalierbarkeit im Marketing',
    solution: 'Aufbau eines vollautomatisierten Marketing-Funnels mit KI-basierter Lead-Qualifizierung',
    result: '250% mehr qualifizierte Leads, 60% niedrigere CAC, vollautomatisches Nurturing',
    image: 'https://images.unsplash.com/photo-1647427060118-4911c9821b82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwYXV0b21hdGlvbiUyMGNvbmNlcHR8ZW58MXx8fHwxNzYxMTk4NjQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    tags: ['Performance Marketing', 'Lead Gen', 'Automation'],
  },
  {
    title: 'Custom Tech Platform',
    client: 'B2B Service Provider',
    problem: 'Legacy-Systeme verhinderten Wachstum und moderne Arbeitsweisen',
    solution: 'Entwicklung einer maßgeschneiderten Tech-Plattform mit nahtlosen Integrationen',
    result: 'Vollständig digitalisierte Prozesse, 10x schnellere Workflows, skalierbare Infrastruktur',
    image: 'https://images.unsplash.com/photo-1542837336-d14bdf342f9b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwd2Vic2l0ZSUyMGRlc2lnbnxlbnwxfHx8fDE3NjExOTg2NDh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    tags: ['Custom Development', 'Integration', 'Tech Stack'],
  },
];

export function CaseStudies() {
  return (
    <section id="cases" className="relative py-32 bg-black">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl mb-6 text-white">
            Case Studies & Ergebnisse
          </h2>
          <p className="text-xl text-white/70 max-w-3xl mx-auto">
            Echte Projekte, messbare Resultate
          </p>
        </motion.div>

        <div className="space-y-8">
          {cases.map((caseStudy, index) => (
            <motion.div
              key={caseStudy.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <motion.div
                whileHover={{ y: -5 }}
                className="group cursor-pointer"
              >
                <div className="grid md:grid-cols-2 gap-8 p-8 lg:p-10 bg-gradient-to-br from-white/5 to-white/[0.02] border border-white/10 rounded-2xl backdrop-blur-sm overflow-hidden">
                  {/* Image */}
                  <div className="relative h-64 md:h-auto rounded-xl overflow-hidden">
                    <ImageWithFallback
                      src={caseStudy.image}
                      alt={caseStudy.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  </div>

                  {/* Content */}
                  <div className="flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <span className="text-sm text-[#C7AB6E]">{caseStudy.client}</span>
                        <span className="text-white/30">•</span>
                        <div className="flex gap-2">
                          {caseStudy.tags.map((tag) => (
                            <span
                              key={tag}
                              className="px-2 py-1 text-xs bg-white/5 text-white/60 rounded border border-white/10"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      <h3 className="text-2xl md:text-3xl text-white mb-4">{caseStudy.title}</h3>

                      <div className="space-y-4 mb-6">
                        <div>
                          <p className="text-sm text-white/50 mb-1">Problem</p>
                          <p className="text-white/80">{caseStudy.problem}</p>
                        </div>

                        <div>
                          <p className="text-sm text-white/50 mb-1">Lösung</p>
                          <p className="text-white/80">{caseStudy.solution}</p>
                        </div>

                        <div className="p-4 bg-[#C7AB6E]/10 border border-[#C7AB6E]/20 rounded-lg">
                          <div className="flex items-start gap-2">
                            <TrendingUp className="w-5 h-5 text-[#C7AB6E] flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="text-sm text-white/50 mb-1">Ergebnis</p>
                              <p className="text-[#C7AB6E]">{caseStudy.result}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <motion.button
                      whileHover={{ x: 5 }}
                      className="flex items-center gap-2 text-white/70 hover:text-[#C7AB6E] transition-colors w-fit"
                    >
                      Full Case Study ansehen
                      <ArrowUpRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mt-12"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            className="px-8 py-4 bg-white/5 text-white border border-white/10 rounded-lg hover:bg-white/10 transition-colors"
          >
            Alle Projekte ansehen
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
