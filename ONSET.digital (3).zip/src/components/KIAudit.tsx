import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, ArrowRight, Check, AlertCircle, TrendingUp, Target, Zap, Shield, BarChart3 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { Progress } from './ui/progress';

interface KIAuditProps {
  onNavigateHome: () => void;
}

interface FormData {
  // Unternehmensprofil
  companyName: string;
  email: string;
  phone: string;
  industry: string;
  companySize: string;
  systems: string;
  digitalizationLevel: number;
  
  // Ziele & Wünsche
  goals: string[];
  specificWishes: string;
  timeline: string;
  
  // Problemstellung
  challenges: string;
  currentSolutions: string;
  workingWell: string;
  notWorking: string;
  
  // Bewertungen für Score
  performanceAccuracy: number;
  userTrust: number;
  userSatisfaction: number;
  userUsability: number;
  costEfficiency: number;
  automationPotential: number;
  scalability: number;
  futureProofing: number;
}

const initialFormData: FormData = {
  companyName: '',
  email: '',
  phone: '',
  industry: '',
  companySize: '',
  systems: '',
  digitalizationLevel: 50,
  goals: [],
  specificWishes: '',
  timeline: '',
  challenges: '',
  currentSolutions: '',
  workingWell: '',
  notWorking: '',
  performanceAccuracy: 50,
  userTrust: 50,
  userSatisfaction: 50,
  userUsability: 50,
  costEfficiency: 50,
  automationPotential: 50,
  scalability: 50,
  futureProofing: 50,
};

export function KIAudit({ onNavigateHome }: KIAuditProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [showResults, setShowResults] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const totalSteps = 4;

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when field is updated
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const toggleGoal = (goal: string) => {
    setFormData(prev => ({
      ...prev,
      goals: prev.goals.includes(goal)
        ? prev.goals.filter(g => g !== goal)
        : [...prev.goals, goal]
    }));
    // Clear goals error when toggling
    if (errors.goals) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors.goals;
        return newErrors;
      });
    }
  };

  const validateStep = (currentStep: number): boolean => {
    const newErrors: Record<string, string> = {};

    switch (currentStep) {
      case 1:
        if (!formData.companyName.trim()) {
          newErrors.companyName = 'Bitte geben Sie Ihren Unternehmensnamen an';
        }
        if (!formData.email.trim()) {
          newErrors.email = 'Bitte geben Sie Ihre E-Mail-Adresse an';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
          newErrors.email = 'Bitte geben Sie eine gültige E-Mail-Adresse an';
        }
        if (!formData.phone.trim()) {
          newErrors.phone = 'Bitte geben Sie Ihre Telefonnummer an';
        }
        if (!formData.industry) {
          newErrors.industry = 'Bitte wählen Sie Ihre Branche aus';
        }
        if (!formData.companySize) {
          newErrors.companySize = 'Bitte wählen Sie Ihre Unternehmensgröße aus';
        }
        break;

      case 2:
        if (formData.goals.length === 0) {
          newErrors.goals = 'Bitte wählen Sie mindestens eine KI-Funktion aus';
        }
        break;

      case 3:
        if (!formData.challenges.trim()) {
          newErrors.challenges = 'Bitte beschreiben Sie Ihre aktuellen Herausforderungen';
        }
        break;

      case 4:
        // Step 4 has sliders, all have default values, so no validation needed
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateScore = () => {
    // Performance & Genauigkeit – 30%
    const performanceScore = formData.performanceAccuracy;
    
    // Nutzerzufriedenheit – 20%
    const userScore = (formData.userTrust + formData.userSatisfaction + formData.userUsability) / 3;
    
    // Wirtschaftlichkeit & Automatisierungspotenzial – 30%
    const economyScore = (formData.costEfficiency + formData.automationPotential) / 2;
    
    // Skalierbarkeit & Zukunftsfähigkeit – 20%
    const scalabilityScore = (formData.scalability + formData.futureProofing) / 2;
    
    const totalScore = 
      (performanceScore * 0.3) +
      (userScore * 0.2) +
      (economyScore * 0.3) +
      (scalabilityScore * 0.2);
    
    return {
      total: Math.round(totalScore),
      categories: [
        { name: 'Performance & Genauigkeit', score: performanceScore, weight: 30, partial: performanceScore * 0.3 },
        { name: 'Nutzerzufriedenheit', score: userScore, weight: 20, partial: userScore * 0.2 },
        { name: 'Wirtschaftlichkeit & Automation', score: economyScore, weight: 30, partial: economyScore * 0.3 },
        { name: 'Skalierbarkeit & Zukunft', score: scalabilityScore, weight: 20, partial: scalabilityScore * 0.2 },
      ]
    };
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 60) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 80) return 'bg-green-500/20 border-green-500/50';
    if (score >= 60) return 'bg-yellow-500/20 border-yellow-500/50';
    return 'bg-red-500/20 border-red-500/50';
  };

  const getProjectPhases = (score: number) => {
    if (score >= 66) {
      // Hoher Score: Schnelle Umsetzung möglich
      return [
        { name: 'Phase 1: Quick Assessment', duration: '1 Woche', description: 'Kurzanalyse & Potenzial-Mapping' },
        { name: 'Phase 2: Konzeption', duration: '1-2 Wochen', description: 'Lösungsdesign & Architektur' },
        { name: 'Phase 3: Implementierung', duration: '4-6 Wochen', description: 'Integration & Automatisierung' },
        { name: 'Phase 4: Testing & Go-Live', duration: '1 Woche', description: 'Quality Assurance & Launch' },
      ];
    } else if (score >= 41) {
      // Mittlerer Score: Moderate Anpassungen nötig
      return [
        { name: 'Phase 1: Discovery & Audit', duration: '2 Wochen', description: 'Detaillierte Analyse & Gap-Assessment' },
        { name: 'Phase 2: Strategie & Konzeption', duration: '2-3 Wochen', description: 'Roadmap & Lösungsdesign' },
        { name: 'Phase 3: Implementierung', duration: '6-8 Wochen', description: 'Entwicklung & Integration' },
        { name: 'Phase 4: Testing & Go-Live', duration: '2 Wochen', description: 'Testing, Schulung & Launch' },
      ];
    } else {
      // Niedriger Score: Umfangreiche Grundlagenarbeit erforderlich
      return [
        { name: 'Phase 1: Foundation & Audit', duration: '3-4 Wochen', description: 'Tiefenanalyse & Prozess-Dokumentation' },
        { name: 'Phase 2: Strategie & Roadmap', duration: '3 Wochen', description: 'Digitalisierungskonzept & Architektur' },
        { name: 'Phase 3: Basis-Implementierung', duration: '4-6 Wochen', description: 'Grundlagen & System-Setup' },
        { name: 'Phase 4: KI-Integration', duration: '6-8 Wochen', description: 'Automatisierung & KI-Workflows' },
        { name: 'Phase 5: Testing & Go-Live', duration: '2-3 Wochen', description: 'Umfassendes Testing & Launch' },
      ];
    }
  };

  const handleSubmit = () => {
    if (validateStep(step)) {
      setShowResults(true);
    }
  };

  const nextStep = () => {
    if (validateStep(step) && step < totalSteps) {
      setStep(step + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
      setErrors({});
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl text-white mb-6">Unternehmensprofil</h3>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-white/80">
                    Unternehmensname <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    value={formData.companyName}
                    onChange={(e) => updateFormData('companyName', e.target.value)}
                    className={`bg-white/5 border-white/10 text-white mt-2 ${errors.companyName ? 'border-red-500' : ''}`}
                    placeholder="Ihr Unternehmensname"
                  />
                  {errors.companyName && (
                    <div className="flex items-center gap-2 mt-2 text-red-500 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.companyName}</span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white/80">
                      E-Mail-Adresse <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData('email', e.target.value)}
                      className={`bg-white/5 border-white/10 text-white mt-2 ${errors.email ? 'border-red-500' : ''}`}
                      placeholder="kontakt@unternehmen.de"
                    />
                    {errors.email && (
                      <div className="flex items-center gap-2 mt-2 text-red-500 text-sm">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.email}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <Label className="text-white/80">
                      Telefonnummer <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => updateFormData('phone', e.target.value)}
                      className={`bg-white/5 border-white/10 text-white mt-2 ${errors.phone ? 'border-red-500' : ''}`}
                      placeholder="+49 123 456789"
                    />
                    {errors.phone && (
                      <div className="flex items-center gap-2 mt-2 text-red-500 text-sm">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.phone}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <Label className="text-white/80">
                    Branche <span className="text-red-500">*</span>
                  </Label>
                  <Select value={formData.industry} onValueChange={(value) => updateFormData('industry', value)}>
                    <SelectTrigger className={`bg-white/5 border-white/10 text-white mt-2 ${errors.industry ? 'border-red-500' : ''}`}>
                      <SelectValue placeholder="Wählen Sie Ihre Branche" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ecommerce">E-Commerce</SelectItem>
                      <SelectItem value="manufacturing">Produktion / Fertigung</SelectItem>
                      <SelectItem value="healthcare">Gesundheitswesen</SelectItem>
                      <SelectItem value="finance">Finanzdienstleistungen</SelectItem>
                      <SelectItem value="retail">Einzelhandel</SelectItem>
                      <SelectItem value="logistics">Logistik</SelectItem>
                      <SelectItem value="services">Dienstleistungen</SelectItem>
                      <SelectItem value="tech">Technologie / IT</SelectItem>
                      <SelectItem value="other">Sonstiges</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.industry && (
                    <div className="flex items-center gap-2 mt-2 text-red-500 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.industry}</span>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-white/80">
                    Unternehmensgröße <span className="text-red-500">*</span>
                  </Label>
                  <Select value={formData.companySize} onValueChange={(value) => updateFormData('companySize', value)}>
                    <SelectTrigger className={`bg-white/5 border-white/10 text-white mt-2 ${errors.companySize ? 'border-red-500' : ''}`}>
                      <SelectValue placeholder="Anzahl Mitarbeiter" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-10">1-10 Mitarbeiter</SelectItem>
                      <SelectItem value="11-50">11-50 Mitarbeiter</SelectItem>
                      <SelectItem value="51-200">51-200 Mitarbeiter</SelectItem>
                      <SelectItem value="201-500">201-500 Mitarbeiter</SelectItem>
                      <SelectItem value="500+">500+ Mitarbeiter</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.companySize && (
                    <div className="flex items-center gap-2 mt-2 text-red-500 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.companySize}</span>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-white/80">Eingesetzte Systeme (WAWI/ERP/CRM)</Label>
                  <Textarea
                    value={formData.systems}
                    onChange={(e) => updateFormData('systems', e.target.value)}
                    className="bg-white/5 border-white/10 text-white mt-2"
                    placeholder="z.B. SAP, Salesforce, eigene Lösung..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label className="text-white/80">
                    Digitalisierungsgrad (0-100): {formData.digitalizationLevel}
                  </Label>
                  <Slider
                    value={[formData.digitalizationLevel]}
                    onValueChange={(value) => updateFormData('digitalizationLevel', value[0])}
                    max={100}
                    step={1}
                    className="mt-4"
                  />
                  <p className="text-white/50 text-sm mt-2">
                    0 = Vollständig analog | 100 = Vollständig digitalisiert
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl text-white mb-6">KI-Automatisierung & Workflows</h3>
              <p className="text-white/60 mb-6">
                Welche Automatisierungen und KI-Workflows interessieren Sie? Wählen Sie alle relevanten Bereiche aus.
              </p>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-white/80 mb-3 block">
                    Gewünschte Automatisierungen <span className="text-red-500">*</span>
                  </Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {[
                      '🔄 Workflow-Automatisierung & Business Logic',
                      '✉️ E-Mail-Automatisierung & Sequenzen',
                      '🔗 System-Integration & API-Workflows',
                      '💬 AI-Chatbots & Virtuelle Assistenten',
                      '📄 Dokumentenverarbeitung mit OCR & AI',
                      '🎯 Lead-Qualifizierung & CRM-Automation',
                      '📊 Datenanalyse & Reporting-Workflows',
                      '🔍 AI Content-Generierung & -Verarbeitung',
                      '📲 Multi-Channel Messaging (WhatsApp, Slack, etc.)',
                      '⏰ Event-basierte Trigger & Monitoring',
                      '🗄️ Datenbank-Synchronisation & ETL',
                      '🤖 Custom AI-Agenten mit LLMs (GPT, Claude)',
                    ].map(goal => (
                      <button
                        key={goal}
                        onClick={() => toggleGoal(goal)}
                        className={`p-3 rounded-lg border transition-all text-left ${
                          formData.goals.includes(goal)
                            ? 'bg-[#C7AB6E]/20 border-[#C7AB6E] text-white'
                            : 'bg-white/5 border-white/10 text-white/70 hover:border-white/30'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {formData.goals.includes(goal) && <Check className="w-4 h-4 text-[#C7AB6E]" />}
                          <span className="text-sm">{goal}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                  {errors.goals && (
                    <div className="flex items-center gap-2 mt-2 text-red-500 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.goals}</span>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-white/80">Spezifische Use Cases & Anforderungen</Label>
                  <Textarea
                    value={formData.specificWishes}
                    onChange={(e) => updateFormData('specificWishes', e.target.value)}
                    className="bg-white/5 border-white/10 text-white mt-2"
                    placeholder="Beschreiben Sie konkrete Workflows, z.B. 'Automatisches Einlesen von E-Mails, KI-Analyse und Weiterleitung ins CRM' oder 'WhatsApp-Bot für Kundensupport mit GPT-4 Integration'"
                    rows={4}
                  />
                </div>

                <div>
                  <Label className="text-white/80">Gewünschter Zeitplan</Label>
                  <Input
                    value={formData.timeline}
                    onChange={(e) => updateFormData('timeline', e.target.value)}
                    className="bg-white/5 border-white/10 text-white mt-2"
                    placeholder="z.B. Q2 2025, Start im März, innerhalb 3 Monate..."
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl text-white mb-6">Problemstellung & Status Quo</h3>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-white/80">
                    Aktuelle Herausforderungen <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    value={formData.challenges}
                    onChange={(e) => updateFormData('challenges', e.target.value)}
                    className={`bg-white/5 border-white/10 text-white mt-2 ${errors.challenges ? 'border-red-500' : ''}`}
                    placeholder="Welche Probleme oder Engpässe haben Sie aktuell?"
                    rows={4}
                  />
                  {errors.challenges && (
                    <div className="flex items-center gap-2 mt-2 text-red-500 text-sm">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.challenges}</span>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-white/80">Aktuelle KI- oder Automationslösungen</Label>
                  <Textarea
                    value={formData.currentSolutions}
                    onChange={(e) => updateFormData('currentSolutions', e.target.value)}
                    className="bg-white/5 border-white/10 text-white mt-2"
                    placeholder="Welche Lösungen nutzen Sie bereits? (falls vorhanden)"
                    rows={3}
                  />
                </div>

                <div>
                  <Label className="text-white/80">Was funktioniert bereits gut?</Label>
                  <Textarea
                    value={formData.workingWell}
                    onChange={(e) => updateFormData('workingWell', e.target.value)}
                    className="bg-white/5 border-white/10 text-white mt-2"
                    placeholder="Beschreiben Sie erfolgreiche Prozesse oder Systeme"
                    rows={3}
                  />
                </div>

                <div>
                  <Label className="text-white/80">Wo gibt es Verbesserungspotenzial?</Label>
                  <Textarea
                    value={formData.notWorking}
                    onChange={(e) => updateFormData('notWorking', e.target.value)}
                    className="bg-white/5 border-white/10 text-white mt-2"
                    placeholder="Was läuft nicht optimal oder fehlt?"
                    rows={3}
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl text-white mb-6">KI-Readiness Bewertung</h3>
              <p className="text-white/60 mb-8">
                Bewerten Sie Ihre aktuellen Systeme und Prozesse auf einer Skala von 0-100
              </p>
              
              <div className="space-y-6">
                <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                  <h4 className="text-white mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-[#C7AB6E]" />
                    Performance & Genauigkeit
                  </h4>
                  <Label className="text-white/80 text-sm">
                    Aktuelle Performance-Level: {formData.performanceAccuracy}
                  </Label>
                  <Slider
                    value={[formData.performanceAccuracy]}
                    onValueChange={(value) => updateFormData('performanceAccuracy', value[0])}
                    max={100}
                    step={1}
                    className="mt-3"
                  />
                </div>

                <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                  <h4 className="text-white mb-4">Nutzerzufriedenheit</h4>
                  
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white/80 text-sm">
                        Vertrauen in Systeme: {formData.userTrust}
                      </Label>
                      <Slider
                        value={[formData.userTrust]}
                        onValueChange={(value) => updateFormData('userTrust', value[0])}
                        max={100}
                        step={1}
                        className="mt-3"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-white/80 text-sm">
                        Zufriedenheit: {formData.userSatisfaction}
                      </Label>
                      <Slider
                        value={[formData.userSatisfaction]}
                        onValueChange={(value) => updateFormData('userSatisfaction', value[0])}
                        max={100}
                        step={1}
                        className="mt-3"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-white/80 text-sm">
                        Bedienbarkeit: {formData.userUsability}
                      </Label>
                      <Slider
                        value={[formData.userUsability]}
                        onValueChange={(value) => updateFormData('userUsability', value[0])}
                        max={100}
                        step={1}
                        className="mt-3"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                  <h4 className="text-white mb-4 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-[#C7AB6E]" />
                    Wirtschaftlichkeit
                  </h4>
                  
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white/80 text-sm">
                        Kosteneffizienz: {formData.costEfficiency}
                      </Label>
                      <Slider
                        value={[formData.costEfficiency]}
                        onValueChange={(value) => updateFormData('costEfficiency', value[0])}
                        max={100}
                        step={1}
                        className="mt-3"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-white/80 text-sm">
                        Automatisierungspotenzial: {formData.automationPotential}
                      </Label>
                      <Slider
                        value={[formData.automationPotential]}
                        onValueChange={(value) => updateFormData('automationPotential', value[0])}
                        max={100}
                        step={1}
                        className="mt-3"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                  <h4 className="text-white mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-[#C7AB6E]" />
                    Skalierbarkeit & Zukunft
                  </h4>
                  
                  <div className="space-y-4">
                    <div>
                      <Label className="text-white/80 text-sm">
                        Skalierbarkeit: {formData.scalability}
                      </Label>
                      <Slider
                        value={[formData.scalability]}
                        onValueChange={(value) => updateFormData('scalability', value[0])}
                        max={100}
                        step={1}
                        className="mt-3"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-white/80 text-sm">
                        Zukunftsfähigkeit: {formData.futureProofing}
                      </Label>
                      <Slider
                        value={[formData.futureProofing]}
                        onValueChange={(value) => updateFormData('futureProofing', value[0])}
                        max={100}
                        step={1}
                        className="mt-3"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (showResults) {
    const scoreData = calculateScore();
    const totalScore = scoreData.total;

    return (
      <div className="min-h-screen bg-black">
        {/* Header */}
        <div className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-xl border-b border-[#C7AB6E]/20">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <button
                onClick={onNavigateHome}
                className="flex items-center gap-2 text-white/80 hover:text-white transition-colors group"
              >
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                Zurück
              </button>
              <span className="text-2xl tracking-tight">
                <span className="text-white">ONSET</span>
                <span className="text-[#C7AB6E]"> DIGITAL</span>
              </span>
            </div>
          </div>
        </div>

        {/* Results */}
        <main className="pt-32 pb-24">
          <div className="max-w-6xl mx-auto px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              {/* Header */}
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full mb-6">
                  <Target className="w-4 h-4 text-[#C7AB6E]" />
                  <span className="text-[#C7AB6E] text-sm">KI-Audit Ergebnis</span>
                </div>
                <h1 className="text-4xl md:text-5xl text-white mb-4">
                  Ihr persönliches KI-Audit
                </h1>
                <p className="text-xl text-white/70">
                  {formData.companyName || 'Ihr Unternehmen'}
                </p>
              </div>

              {/* Overall Score */}
              <div className={`rounded-2xl border p-8 mb-12 text-center ${getScoreBgColor(totalScore)}`}>
                <h2 className="text-white/80 mb-4">Gesamtscore</h2>
                <div className={`text-7xl mb-2 ${getScoreColor(totalScore)}`}>
                  {totalScore}
                </div>
                <p className="text-white/60">von 100 Punkten</p>
                <div className="mt-6 max-w-md mx-auto">
                  <Progress value={totalScore} className="h-3" />
                </div>
                <p className="text-white/80 mt-6">
                  {totalScore >= 80 && 'Exzellent! Ihre KI-Readiness ist sehr hoch.'}
                  {totalScore >= 60 && totalScore < 80 && 'Gut! Es gibt noch Optimierungspotenzial.'}
                  {totalScore < 60 && 'Verbesserungswürdig. Wir zeigen Ihnen, wie Sie vorankommen.'}
                </p>
              </div>

              {/* Score Categories */}
              <div className="bg-white/5 border border-white/10 rounded-2xl p-8 mb-12">
                <h2 className="text-2xl text-white mb-6">Detaillierte Bewertung</h2>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-white/10">
                        <th className="text-left text-white/80 py-3 px-4">Kategorie</th>
                        <th className="text-center text-white/80 py-3 px-4">Score</th>
                        <th className="text-center text-white/80 py-3 px-4">Gewichtung</th>
                        <th className="text-center text-white/80 py-3 px-4">Teilscore</th>
                        <th className="text-center text-white/80 py-3 px-4">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {scoreData.categories.map((cat, index) => (
                        <tr key={index} className="border-b border-white/10">
                          <td className="text-white py-4 px-4">{cat.name}</td>
                          <td className="text-center py-4 px-4">
                            <span className={getScoreColor(cat.score)}>
                              {Math.round(cat.score)}
                            </span>
                          </td>
                          <td className="text-center text-white/70 py-4 px-4">{cat.weight}%</td>
                          <td className="text-center text-white py-4 px-4">
                            {cat.partial.toFixed(1)}
                          </td>
                          <td className="text-center py-4 px-4">
                            <div className={`inline-block w-3 h-3 rounded-full ${
                              cat.score >= 80 ? 'bg-green-500' :
                              cat.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                            }`} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Company Profile */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                  <h3 className="text-xl text-white mb-4">Unternehmensprofil</h3>
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="text-white/60">Branche:</span>
                      <span className="text-white ml-2">{formData.industry || 'Nicht angegeben'}</span>
                    </div>
                    <div>
                      <span className="text-white/60">Größe:</span>
                      <span className="text-white ml-2">{formData.companySize || 'Nicht angegeben'}</span>
                    </div>
                    <div>
                      <span className="text-white/60">Digitalisierungsgrad:</span>
                      <span className="text-white ml-2">{formData.digitalizationLevel}%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                  <h3 className="text-xl text-white mb-4">Projektziele</h3>
                  <div className="space-y-2">
                    {formData.goals.length > 0 ? (
                      formData.goals.map((goal, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-[#C7AB6E]" />
                          <span className="text-white/80 text-sm">{goal}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-white/60 text-sm">Keine Ziele angegeben</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="space-y-6 mb-12">
                <h2 className="text-2xl text-white">Maßnahmen & Empfehlungen</h2>
                
                {/* Quick Wins */}
                <div className="bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/30 rounded-xl p-6">
                  <h3 className="text-xl text-white mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-green-500" />
                    Quick Wins (sofort umsetzbar)
                  </h3>
                  <ul className="space-y-2 text-white/80">
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">•</span>
                      <span>Prozessanalyse durchführen und Automatisierungspotenziale identifizieren</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">•</span>
                      <span>Standard-KI-Tools für häufige Aufgaben testen (z.B. Dokumentenverarbeitung)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">•</span>
                      <span>Team-Workshop zur KI-Awareness und ersten Use Cases</span>
                    </li>
                  </ul>
                </div>

                {/* Medium Term */}
                <div className="bg-gradient-to-br from-yellow-500/10 to-transparent border border-yellow-500/30 rounded-xl p-6">
                  <h3 className="text-xl text-white mb-4 flex items-center gap-2">
                    <Target className="w-5 h-5 text-yellow-500" />
                    Mittelfristig (3-6 Monate)
                  </h3>
                  <ul className="space-y-2 text-white/80">
                    <li className="flex items-start gap-2">
                      <span className="text-yellow-500 mt-1">•</span>
                      <span>KI-gestützte Automation-Workflows implementieren</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-yellow-500 mt-1">•</span>
                      <span>Integration mit bestehenden Systemen ({formData.systems || 'Ihre Systeme'})</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-yellow-500 mt-1">•</span>
                      <span>Schulungen für Mitarbeiter zu neuen KI-Tools</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-yellow-500 mt-1">•</span>
                      <span>Erste Pilotprojekte mit messbaren KPIs starten</span>
                    </li>
                  </ul>
                </div>

                {/* Long Term */}
                <div className="bg-gradient-to-br from-[#C7AB6E]/10 to-transparent border border-[#C7AB6E]/30 rounded-xl p-6">
                  <h3 className="text-xl text-white mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-[#C7AB6E]" />
                    Langfristige Potenziale (6+ Monate)
                  </h3>
                  <ul className="space-y-2 text-white/80">
                    <li className="flex items-start gap-2">
                      <span className="text-[#C7AB6E] mt-1">•</span>
                      <span>Custom KI-Modelle für branchenspezifische Anforderungen</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#C7AB6E] mt-1">•</span>
                      <span>Vollständige WAWI/ERP-Integration mit KI-Automatisierung</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#C7AB6E] mt-1">•</span>
                      <span>Skalierung auf weitere Geschäftsbereiche</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#C7AB6E] mt-1">•</span>
                      <span>Predictive Analytics für datengestützte Entscheidungen</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Offer Concept */}
              <div className="bg-gradient-to-b from-[#C7AB6E]/10 to-transparent border border-[#C7AB6E]/30 rounded-2xl p-8 mb-12">
                <h2 className="text-2xl text-white mb-6">Individuelles Angebotskonzept</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h3 className="text-white mb-3">Leistungsumfang</h3>
                    <ul className="space-y-2 text-white/80 text-sm">
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#C7AB6E]" />
                        <span>Detailliertes KI-Audit & Prozessanalyse</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#C7AB6E]" />
                        <span>Konzeption maßgeschneiderter KI-Lösungen</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#C7AB6E]" />
                        <span>Implementierung & System-Integration</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#C7AB6E]" />
                        <span>Testing & Quality Assurance</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#C7AB6E]" />
                        <span>Team-Schulungen & Dokumentation</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-[#C7AB6E]" />
                        <span>3 Monate Post-Launch Support</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-white mb-3">Projektphasen</h3>
                    <div className="space-y-3">
                      {getProjectPhases(totalScore).map((phase, index) => (
                        <div key={index} className="bg-white/5 rounded-lg p-3">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-white text-sm">{phase.name}</span>
                            <span className="text-white/60 text-sm">{phase.duration}</span>
                          </div>
                          <div className="text-white/50 text-xs mt-1">{phase.description}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* CTA */}
              <div className="text-center">
                <motion.a
                  href="mailto:hello@onsetdigital.com?subject=KI-Audit Ergebnis - Nächste Schritte"
                  className="inline-flex items-center gap-2 px-8 py-4 bg-[#C7AB6E] text-black rounded-lg hover:bg-[#d4b87a] transition-colors"
                  whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(199, 171, 110, 0.6)' }}
                  whileTap={{ scale: 0.98 }}
                >
                  Kostenloses Beratungsgespräch vereinbaren
                  <ArrowRight className="w-5 h-5" />
                </motion.a>
                <p className="text-white/60 text-sm mt-4">
                  Wir melden uns innerhalb von 24 Stunden bei Ihnen
                </p>
              </div>
            </motion.div>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-white/10">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/50">
              <p>© 2025 ONSET DIGITAL. All rights reserved.</p>
              <button onClick={onNavigateHome} className="hover:text-[#C7AB6E] transition-colors">
                Zur Startseite
              </button>
            </div>
          </div>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Form */}
      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Header */}
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full mb-6">
                <Target className="w-4 h-4 text-[#C7AB6E]" />
                <span className="text-[#C7AB6E] text-sm">Kostenloses KI-Audit</span>
              </div>
              <h1 className="text-4xl md:text-5xl text-white mb-4">
                Entdecken Sie Ihr KI-Potenzial
              </h1>
              <p className="text-xl text-white/70 mb-4">
                In wenigen Schritten zu Ihrer individuellen KI-Analyse
              </p>
              
              <p className="text-white/50 text-sm mb-8">
                Felder mit <span className="text-red-500">*</span> sind Pflichtfelder
              </p>
              
              {/* Progress */}
              <div className="max-w-md mx-auto">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white/60 text-sm">Schritt {step} von {totalSteps}</span>
                  <span className="text-white/60 text-sm">{Math.round((step / totalSteps) * 100)}%</span>
                </div>
                <Progress value={(step / totalSteps) * 100} className="h-2" />
              </div>
            </div>

            {/* Form Content */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8 mb-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  {renderStep()}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between">
              <Button
                onClick={prevStep}
                disabled={step === 1}
                variant="outline"
                className="bg-white/5 border-white/10 text-white hover:bg-white/10 disabled:opacity-50"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Zurück
              </Button>

              {step < totalSteps ? (
                <Button
                  onClick={nextStep}
                  className="bg-[#C7AB6E] text-black hover:bg-[#d4b87a]"
                >
                  Weiter
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  className="bg-[#C7AB6E] text-black hover:bg-[#d4b87a]"
                >
                  Ergebnis anzeigen
                  <Check className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
