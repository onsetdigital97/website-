import { motion } from 'motion/react';
import { Brain, Zap, Palette, TrendingUp } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'KI-Automatisierung',
    description: 'Intelligente Systeme, die manuelle Prozesse ersetzen und Ihr Unternehmen 24/7 skalieren',
  },
  {
    icon: Zap,
    title: 'Custom Tech Solutions',
    description: 'Maßgeschneiderte technische Lösungen, die perfekt zu Ihren Geschäftsprozessen passen',
  },
  {
    icon: Palette,
    title: 'Branding & Webdesign',
    description: 'Premium Design mit Fokus auf UX/UI – für digitale Erlebnisse, die konvertieren',
  },
  {
    icon: TrendingUp,
    title: 'Performance & Skalierung',
    description: 'Datengetriebene Strategien für messbares Wachstum und nachhaltige Skalierung',
  },
];

export function WhyUs() {
  return (
    <section className="relative py-32 bg-black overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#C7AB6E]/5 to-transparent" />
      <div className="absolute top-1/2 left-0 w-[600px] h-[600px] bg-[#C7AB6E]/5 rounded-full blur-[150px] -translate-y-1/2" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        {/* Main Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl mb-6">
            <span className="text-white">Warum </span>
            <span className="text-[#C7AB6E]">ONSET DIGITAL</span>
            <span className="text-white">?</span>
          </h2>
          <p className="text-2xl text-white/90 mb-4">
            Engineers, Creators & Strategists
          </p>
          <p className="text-xl text-white/70 max-w-3xl mx-auto">
            Wir sind kein klassisches Agentur-Team – wir bauen skalierbare, KI-gesteuerte Systeme und kombinieren technische Expertise mit kreativem Denken
          </p>
        </motion.div>

        {/* Core Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <motion.div
                whileHover={{ y: -8, scale: 1.02 }}
                className="h-full p-8 bg-gradient-to-br from-white/5 to-white/[0.02] border border-white/10 rounded-2xl backdrop-blur-sm group cursor-pointer"
              >
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-14 h-14 bg-[#C7AB6E]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#C7AB6E]/20 transition-colors"
                >
                  <feature.icon className="w-7 h-7 text-[#C7AB6E]" />
                </motion.div>
                
                <h3 className="text-xl text-white mb-3">{feature.title}</h3>
                <p className="text-white/60 leading-relaxed">{feature.description}</p>

                {/* Hover glow effect */}
                <div className="absolute inset-0 bg-[#C7AB6E]/0 group-hover:bg-[#C7AB6E]/5 rounded-2xl transition-colors duration-300 -z-10" />
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
