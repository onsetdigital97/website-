import { motion } from 'motion/react';
import { ArrowLeft, Check, Clock, Sparkles, Zap, Crown, ArrowRight } from 'lucide-react';
import { Footer } from './Footer';

interface SupportPackagesProps {
  onNavigateHome: () => void;
  onNavigateToPrivacy?: () => void;
  onNavigateToImprint?: () => void;
  onNavigateToTerms?: () => void;
}

const packages = [
  {
    name: 'Starter',
    icon: Sparkles,
    hours: '10',
    price: '1.250',
    pricePerHour: '125',
    description: 'Ideal für kleinere Anpassungen und punktuelle Unterstützung',
    features: [
      'Flexibel einsetzbare Stunden',
      'E-Mail Support',
      'Stundensatz: 125€',
      'Gültigkeit: 3 Monate',
      'Alle Services verfügbar',
      'Transparentes Reporting',
    ],
    highlight: false,
    mailtoSubject: 'Anfrage: Starter Stundenpaket (10h)',
    mailtoBody: `Hallo ONSET DIGITAL Team,%0D%0A%0D%0AIch interessiere mich für das Starter Stundenpaket mit 10 Stunden.%0D%0A%0D%0AMein Projekt/Anliegen:%0D%0A[Bitte hier beschreiben]%0D%0A%0D%0AGewünschte Services:%0D%0A[z.B. KI-Automation, Webentwicklung, Performance Marketing]%0D%0A%0D%0AZeitrahmen:%0D%0A[Wann möchten Sie starten?]%0D%0A%0D%0ABitte kontaktieren Sie mich für weitere Details.%0D%0A%0D%0AMit freundlichen Grüßen`,
  },
  {
    name: 'Professional',
    icon: Zap,
    hours: '25',
    price: '2.750',
    pricePerHour: '110',
    savings: '375',
    description: 'Perfekt für mittlere Projekte und kontinuierliche Optimierung',
    features: [
      'Flexibel einsetzbare Stunden',
      'Priority E-Mail Support',
      'Stundensatz: 110€ (statt 125€)',
      'Gültigkeit: 6 Monate',
      'Alle Services verfügbar',
      'Monatliches Status-Update',
      'Transparentes Reporting',
      'Ersparnis: 375€',
    ],
    highlight: true,
    mailtoSubject: 'Anfrage: Professional Stundenpaket (25h)',
    mailtoBody: `Hallo ONSET DIGITAL Team,%0D%0A%0D%0AIch interessiere mich für das Professional Stundenpaket mit 25 Stunden.%0D%0A%0D%0AMein Projekt/Anliegen:%0D%0A[Bitte hier beschreiben]%0D%0A%0D%0AGewünschte Services:%0D%0A[z.B. KI-Automation, Webentwicklung, Performance Marketing]%0D%0A%0D%0AZeitrahmen:%0D%0A[Wann möchten Sie starten?]%0D%0A%0D%0AWeitere Informationen:%0D%0A[Optional: Gibt es bereits konkrete Anforderungen?]%0D%0A%0D%0ABitte kontaktieren Sie mich für ein unverbindliches Gespräch.%0D%0A%0D%0AMit freundlichen Grüßen`,
  },
  {
    name: 'Enterprise',
    icon: Crown,
    hours: '35',
    price: '3.500',
    pricePerHour: '100',
    savings: '875',
    description: 'Für umfangreiche Projekte und langfristige Zusammenarbeit',
    features: [
      'Flexibel einsetzbare Stunden',
      'Premium Support (24h Response)',
      'Stundensatz: 100€ (statt 125€)',
      'Gültigkeit: 12 Monate',
      'Alle Services verfügbar',
      'Dedizierter Ansprechpartner',
      'Bi-Weekly Status-Calls',
      'Strategische Beratung inklusive',
      'Transparentes Reporting',
      'Ersparnis: 875€',
    ],
    highlight: false,
    mailtoSubject: 'Anfrage: Enterprise Stundenpaket (35h)',
    mailtoBody: `Hallo ONSET DIGITAL Team,%0D%0A%0D%0AIch interessiere mich für das Enterprise Stundenpaket mit 35 Stunden.%0D%0A%0D%0AMein Projekt/Anliegen:%0D%0A[Bitte hier beschreiben]%0D%0A%0D%0AGewünschte Services:%0D%0A[z.B. KI-Automation, Webentwicklung, Performance Marketing, Tech Consulting]%0D%0A%0D%0AZeitrahmen:%0D%0A[Wann möchten Sie starten?]%0D%0A%0D%0AUnternehmen:%0D%0A[Firmenname]%0D%0A%0D%0AWeitere Informationen:%0D%0A[Optional: Spezifische Anforderungen oder strategische Ziele]%0D%0A%0D%0AIch freue mich auf ein persönliches Gespräch zur Planung der Zusammenarbeit.%0D%0A%0D%0AMit freundlichen Grüßen`,
  },
];

export function SupportPackages({ 
  onNavigateHome,
  onNavigateToPrivacy,
  onNavigateToImprint,
  onNavigateToTerms,
}: SupportPackagesProps) {
  return (
    <div className="min-h-screen bg-black">
      {/* Content */}
      <main className="pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {/* Header Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-20 text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full mb-6">
              <Clock className="w-4 h-4 text-[#C7AB6E]" />
              <span className="text-[#C7AB6E] text-sm">Stundenbasierte Projekte</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl text-white mb-6">
              Flexibel buchbare Stundenpakete
            </h1>
            
            <p className="text-xl text-white/70 max-w-3xl mx-auto mb-4">
              Buchen Sie Stundenkontingente für projektbasierte Unterstützung. Nutzen Sie die Stunden flexibel für alle unsere Services – von KI-Automation bis Performance Marketing.
            </p>
            
            <p className="text-sm text-white/50">
              Alle Preise verstehen sich netto zzgl. gesetzlicher MwSt.
            </p>
          </motion.div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-24">
            {packages.map((pkg, index) => {
              const Icon = pkg.icon;
              return (
                <motion.div
                  key={pkg.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  className={`relative rounded-2xl p-8 ${
                    pkg.highlight
                      ? 'bg-gradient-to-b from-[#C7AB6E]/20 to-black border-2 border-[#C7AB6E]/50'
                      : 'bg-white/5 border border-white/10'
                  }`}
                >
                  {pkg.highlight && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[#C7AB6E] text-black text-sm rounded-full">
                      Beliebt
                    </div>
                  )}

                  <div className="mb-6">
                    <div className={`inline-flex p-3 rounded-xl mb-4 ${
                      pkg.highlight ? 'bg-[#C7AB6E]/20' : 'bg-white/5'
                    }`}>
                      <Icon className={`w-6 h-6 ${
                        pkg.highlight ? 'text-[#C7AB6E]' : 'text-white/70'
                      }`} />
                    </div>
                    <h3 className="text-2xl text-white mb-2">{pkg.name}</h3>
                    <p className="text-white/60 text-sm mb-6">{pkg.description}</p>
                    
                    <div className="mb-4">
                      <div className="flex items-baseline gap-2 mb-1">
                        <span className="text-4xl text-white">{pkg.price}€</span>
                      </div>
                      <div className="flex items-center gap-2 text-white/70">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm">{pkg.hours} Stunden</span>
                      </div>
                    </div>

                    {pkg.savings && (
                      <div className="inline-flex px-3 py-1 bg-[#C7AB6E]/20 border border-[#C7AB6E]/30 rounded-full mb-4">
                        <span className="text-[#C7AB6E] text-sm">Sie sparen {pkg.savings}€</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3 mb-8">
                    {pkg.features.map((feature, i) => (
                      <div key={i} className="flex items-start gap-3">
                        <Check className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
                          pkg.highlight ? 'text-[#C7AB6E]' : 'text-white/70'
                        }`} />
                        <span className="text-white/80 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <motion.a
                    href={`mailto:info@onsetdigital.de?subject=${pkg.mailtoSubject}&body=${pkg.mailtoBody}`}
                    className={`w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg transition-colors ${
                      pkg.highlight
                        ? 'bg-[#C7AB6E] text-black hover:bg-[#d4b87a]'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Paket buchen
                    <ArrowRight className="w-4 h-4" />
                  </motion.a>
                </motion.div>
              );
            })}
          </div>

          {/* Use Cases Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl text-white mb-4">
                Wofür können Sie die Stunden nutzen?
              </h2>
              <p className="text-white/70">
                Alle unsere Services sind flexibel mit den Stundenpaketen kombinierbar
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: 'KI-Automation',
                  description: 'Optimierung, Fehlerbehebung und kleine Anpassungen bestehender KI-Agenten. Für gezielte Unterstützung – nicht für Neuentwicklungen.',
                },
                {
                  title: 'Website-Entwicklung',
                  description: 'Anpassungen, neue Features und Performance-Optimierung Ihrer Website',
                },
                {
                  title: 'Performance Marketing',
                  description: 'Kampagnen-Setup, Optimierung und kontinuierliche Verbesserung',
                },
                {
                  title: 'Branding & Design',
                  description: 'Unterstützung bei kleineren Grafikaufgaben, visuellen Anpassungen oder Fragen zum Branding. Für laufende Markenpflege und optische Konsistenz.',
                },
                {
                  title: 'Tech Consulting',
                  description: 'Strategische Beratung zu Technologie-Entscheidungen und Roadmaps',
                },
                {
                  title: 'Support',
                  description: 'Telefon- und E-Mail-Support für Ihre Fragen und Anliegen',
                },
              ].map((useCase, index) => (
                <motion.div
                  key={useCase.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.5 + index * 0.1 }}
                  className="bg-white/5 border border-white/10 rounded-xl p-6 hover:border-[#C7AB6E]/30 transition-colors"
                >
                  <h3 className="text-white mb-2">{useCase.title}</h3>
                  <p className="text-white/60 text-sm">{useCase.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* FAQ Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl text-white mb-4">
                Häufig gestellte Fragen
              </h2>
            </div>

            <div className="max-w-3xl mx-auto space-y-6">
              {[
                {
                  question: 'Wie lange sind die Stunden gültig?',
                  answer: 'Die Gültigkeit variiert je nach Paket: Starter 3 Monate, Professional 6 Monate, Enterprise 12 Monate. Nicht genutzte Stunden verfallen nach Ablauf.',
                },
                {
                  question: 'Kann ich Stunden für verschiedene Services nutzen?',
                  answer: 'Ja, die Stunden sind flexibel für alle unsere Services einsetzbar – von KI-Automation über Webentwicklung bis hin zu Performance Marketing.',
                },
                {
                  question: 'Wie wird der Stundenverbrauch dokumentiert?',
                  answer: 'Sie erhalten ein transparentes Reporting mit detaillierter Aufschlüsselung aller genutzten Stunden inkl. Aufgabenbeschreibung und Zeiterfassung.',
                },
                {
                  question: 'Was passiert, wenn meine Stunden aufgebraucht sind?',
                  answer: 'Sie können jederzeit ein neues Paket buchen oder einzelne Stunden zum regulären Stundensatz von 125€ dazu kaufen.',
                },
                {
                  question: 'Kann ich ein Paket upgraden?',
                  answer: 'Ja, Sie können jederzeit auf ein größeres Paket upgraden. Die bereits genutzten Stunden werden anteilig verrechnet.',
                },
              ].map((faq, index) => (
                <div
                  key={index}
                  className="bg-white/5 border border-white/10 rounded-xl p-6"
                >
                  <h3 className="text-white mb-3">{faq.question}</h3>
                  <p className="text-white/70 text-sm">{faq.answer}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Benefits Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="mb-20"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: Sparkles,
                  title: 'Keine versteckten Kosten',
                  description: 'Sie erhalten ein genaues Tracking wofür Sie Ihre Stunden aufbrauchen.',
                },
                {
                  icon: Zap,
                  title: 'Flexible Nutzung',
                  description: 'Nutzen Sie Ihre Stunden flexibel für alle unsere Services und Leistungsbereiche.',
                },
                {
                  icon: Crown,
                  title: 'Premium Qualität',
                  description: 'Höchste Qualitätsstandards für Ihre Projekte.',
                },
              ].map((benefit, index) => {
                const Icon = benefit.icon;
                return (
                  <div
                    key={benefit.title}
                    className="text-center"
                  >
                    <div className="inline-flex p-4 bg-[#C7AB6E]/10 rounded-xl mb-4">
                      <Icon className="w-8 h-8 text-[#C7AB6E]" />
                    </div>
                    <h3 className="text-white mb-2">{benefit.title}</h3>
                    <p className="text-white/60 text-sm">{benefit.description}</p>
                  </div>
                );
              })}
            </div>
          </motion.div>


        </div>
      </main>

      {/* Footer */}
      <Footer 
        onNavigateToPrivacy={onNavigateToPrivacy}
        onNavigateToImprint={onNavigateToImprint}
        onNavigateToTerms={onNavigateToTerms}
      />
    </div>
  );
}
