import { motion } from 'motion/react';
import { FileText, ArrowLeft } from 'lucide-react';

interface TermsProps {
  onNavigateHome: () => void;
}

export function Terms({ onNavigateHome }: TermsProps) {
  return (
    <div className="min-h-screen bg-black">
      {/* Content */}
      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          {/* Header Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full mb-6">
              <FileText className="w-4 h-4 text-[#C7AB6E]" />
              <span className="text-[#C7AB6E] text-sm">Rechtliche Informationen</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl text-white mb-6">
              Allgemeine Geschäftsbedingungen
            </h1>
            
            <p className="text-xl text-white/70">
              Geltungsbereich und Vertragsgrundlagen für die Zusammenarbeit mit ONSET DIGITAL
            </p>
          </motion.div>

          {/* Content Sections */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-12"
          >
            {/* Section 1 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">1. Geltungsbereich</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Diese Allgemeinen Geschäftsbedingungen (AGB) gelten für alle Verträge zwischen ONSET DIGITAL (nachfolgend "Auftragnehmer") und dem Kunden (nachfolgend "Auftraggeber") über die Erbringung von Dienstleistungen im Bereich KI-Automation, Branding, Webdesign, Performance Marketing und Tech Development.
                </p>
                <p>
                  Abweichende Bedingungen des Auftraggebers werden nicht anerkannt, es sei denn, der Auftragnehmer stimmt ihrer Geltung ausdrücklich schriftlich zu.
                </p>
              </div>
            </section>

            {/* Section 2 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">2. Vertragsschluss</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Der Vertrag kommt durch die schriftliche Auftragsbestätigung des Auftragnehmers oder durch Beginn der Leistungserbringung zustande. Angebote des Auftragnehmers sind freibleibend und unverbindlich, sofern nicht ausdrücklich als verbindlich gekennzeichnet.
                </p>
                <p>
                  Änderungen und Ergänzungen des Vertrages bedürfen zu ihrer Wirksamkeit der Schriftform. Dies gilt auch für die Aufhebung des Schriftformerfordernisses.
                </p>
              </div>
            </section>

            {/* Section 3 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">3. Leistungsumfang</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Der Umfang der zu erbringenden Leistungen ergibt sich aus der jeweiligen Leistungsbeschreibung bzw. dem individuellen Angebot. Zusätzliche Leistungen werden gesondert vergütet.
                </p>
                <p>
                  Der Auftragnehmer ist berechtigt, sich zur Erfüllung seiner Leistungspflichten qualifizierter Dritter als Erfüllungsgehilfen zu bedienen.
                </p>
              </div>
            </section>

            {/* Section 4 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">4. Mitwirkungspflichten des Auftraggebers</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Der Auftraggeber stellt dem Auftragnehmer alle für die Durchführung des Auftrags erforderlichen Informationen, Daten und Materialien vollständig und rechtzeitig zur Verfügung.
                </p>
                <p>
                  Der Auftraggeber ist verpflichtet, die vom Auftragnehmer erstellten Entwürfe und Konzepte zeitnah zu prüfen und etwaige Änderungswünsche mitzuteilen. Verzögerungen aufgrund verspäteter Rückmeldungen des Auftraggebers gehen nicht zu Lasten des Auftragnehmers.
                </p>
              </div>
            </section>

            {/* Section 5 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">5. Vergütung und Zahlungsbedingungen</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Die Vergütung richtet sich nach der jeweiligen Vereinbarung. Sofern nichts anderes vereinbart wurde, gelten die zum Zeitpunkt der Auftragserteilung gültigen Preise.
                </p>
                <p>
                  Rechnungen sind innerhalb von 14 Tagen nach Rechnungsdatum ohne Abzug zu zahlen, sofern nicht anders vereinbart. Bei Zahlungsverzug werden Verzugszinsen in Höhe von 9 Prozentpunkten über dem Basiszinssatz berechnet.
                </p>
                <p>
                  Der Auftragnehmer ist berechtigt, angemessene Abschlagszahlungen zu verlangen oder Leistungen von Vorauszahlungen abhängig zu machen.
                </p>
              </div>
            </section>

            {/* Section 6 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">6. Urheberrechte und Nutzungsrechte</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Alle im Rahmen des Auftrags erstellten Werke (Designs, Konzepte, Codes, Texte, etc.) unterliegen dem Urheberrecht. Der Auftragnehmer räumt dem Auftraggeber nach vollständiger Bezahlung die vertraglich vereinbarten Nutzungsrechte ein.
                </p>
                <p>
                  Sofern nicht ausdrücklich anders vereinbart, erhält der Auftraggeber einfache Nutzungsrechte für die vertraglich vereinbarten Zwecke. Eine Weitergabe an Dritte oder eine über den vereinbarten Zweck hinausgehende Nutzung bedarf der vorherigen schriftlichen Zustimmung des Auftragnehmers.
                </p>
                <p>
                  Der Auftragnehmer ist berechtigt, die im Rahmen des Auftrags erstellten Arbeiten zu Referenzzwecken zu verwenden und zu veröffentlichen.
                </p>
              </div>
            </section>

            {/* Section 7 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">7. Gewährleistung</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Der Auftragnehmer gewährleistet, dass die erbrachten Leistungen zum Zeitpunkt der Abnahme im Wesentlichen der vereinbarten Beschaffenheit entsprechen.
                </p>
                <p>
                  Mängelansprüche verjähren innerhalb von 12 Monaten ab Abnahme der Leistung. Bei vorsätzlichem oder grob fahrlässigem Verhalten sowie bei Verletzung von Leben, Körper oder Gesundheit gelten die gesetzlichen Verjährungsfristen.
                </p>
                <p>
                  Im Falle eines Mangels ist der Auftragnehmer zunächst zur Nacherfüllung berechtigt. Schlägt die Nacherfüllung fehl, kann der Auftraggeber nach seiner Wahl Minderung verlangen oder vom Vertrag zurücktreten.
                </p>
              </div>
            </section>

            {/* Section 8 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">8. Haftung</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Der Auftragnehmer haftet unbeschränkt für Schäden aus der Verletzung des Lebens, des Körpers oder der Gesundheit, die auf einer fahrlässigen oder vorsätzlichen Pflichtverletzung des Auftragnehmers oder eines seiner gesetzlichen Vertreter oder Erfüllungsgehilfen beruhen.
                </p>
                <p>
                  Für sonstige Schäden haftet der Auftragnehmer nur bei Vorsatz und grober Fahrlässigkeit sowie bei der fahrlässigen Verletzung wesentlicher Vertragspflichten. Im Falle der Verletzung wesentlicher Vertragspflichten ist die Haftung auf den vertragstypischen, vorhersehbaren Schaden begrenzt.
                </p>
                <p>
                  Die Haftung nach dem Produkthaftungsgesetz bleibt unberührt.
                </p>
              </div>
            </section>

            {/* Section 9 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">9. Vertraulichkeit und Datenschutz</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Beide Vertragsparteien verpflichten sich, alle im Rahmen der Zusammenarbeit bekannt gewordenen vertraulichen Informationen streng vertraulich zu behandeln und nur für die Zwecke der Vertragserfüllung zu verwenden.
                </p>
                <p>
                  Die Verarbeitung personenbezogener Daten erfolgt in Übereinstimmung mit den geltenden datenschutzrechtlichen Bestimmungen, insbesondere der DSGVO.
                </p>
              </div>
            </section>

            {/* Section 10 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">10. Kündigung</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Das Recht zur außerordentlichen Kündigung aus wichtigem Grund bleibt unberührt. Ein wichtiger Grund liegt insbesondere vor, wenn der Auftraggeber mit der Zahlung von zwei aufeinanderfolgenden Abschlagszahlungen oder einem nicht unerheblichen Teil davon in Verzug ist.
                </p>
                <p>
                  Im Falle der Kündigung durch den Auftraggeber ohne wichtigen Grund hat der Auftragnehmer Anspruch auf Vergütung der bis dahin erbrachten Leistungen sowie auf Erstattung der entstandenen Auslagen.
                </p>
              </div>
            </section>

            {/* Section 11 */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">11. Schlussbestimmungen</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Es gilt das Recht der Bundesrepublik Deutschland unter Ausschluss des UN-Kaufrechts.
                </p>
                <p>
                  Erfüllungsort und ausschließlicher Gerichtsstand für alle Streitigkeiten aus diesem Vertrag ist der Sitz des Auftragnehmers, sofern der Auftraggeber Kaufmann, juristische Person des öffentlichen Rechts oder öffentlich-rechtliches Sondervermögen ist.
                </p>
                <p>
                  Sollten einzelne Bestimmungen dieser AGB unwirksam sein oder werden, bleibt die Wirksamkeit der übrigen Bestimmungen davon unberührt. Die unwirksame Bestimmung ist durch eine wirksame zu ersetzen, die dem wirtschaftlichen Zweck der unwirksamen Bestimmung am nächsten kommt.
                </p>
              </div>
            </section>

            {/* Last Updated */}
            <div className="pt-8 border-t border-white/10">
              <p className="text-white/50 text-sm">
                Stand: Oktober 2025
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/50">
            <p>© 2025 ONSET DIGITAL. All rights reserved.</p>
            <div className="flex gap-6">
              <button onClick={onNavigateHome} className="hover:text-[#C7AB6E] transition-colors">
                Zur Startseite
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
