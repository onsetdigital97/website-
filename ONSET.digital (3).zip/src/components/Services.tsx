import { motion, AnimatePresence } from 'motion/react';
import { Bot, Sparkles, TrendingUp, Database, ArrowRight, ChevronDown, ShoppingCart } from 'lucide-react';
import { useState } from 'react';

const services = [
  {
    icon: Bot,
    title: 'KI-Automation & Prozess-Digitalisierung',
    description: 'Automatisierung von Workflows, Lead-Management, Reporting & mehr. Wir ersetzen repetitive Arbeit durch intelligente Systeme.',
    features: ['Lead-Automatisierung', 'Workflow-Optimierung', 'Smart Analytics', 'E-Mail-Automation'],
    detailedDescription: 'Wir entwickeln maßgeschneiderte KI-gestützte Automatisierungslösungen, die Ihre Geschäftsprozesse revolutionieren. Von der automatischen Lead-Qualifizierung über intelligentes Reporting bis hin zu vollständig autonomen Workflows – unsere Systeme lernen kontinuierlich und optimieren sich selbst. Dabei setzen wir auf moderne Low-Code-Plattformen wie n8n in Kombination mit leistungsstarken LLMs (GPT-4, Claude) für maximale Flexibilität und schnelle Implementierung.',
    highlight: true,
  },
  {
    icon: Sparkles,
    title: 'Branding & UX/UI Webdesign',
    description: 'Premium Design mit Fokus auf User Experience. Von der Brand Identity über professionelle Fotografie bis zur konversionsoptimierten Website.',
    features: ['Brand Identity', 'Web Design', 'UI/UX Design', 'Fotografie', 'Design Systems'],
    detailedDescription: 'Unser Design-Team kreiert visuelle Identitäten, die begeistern und konvertieren. Wir entwickeln durchdachte Design Systems, die sowohl ästhetisch ansprechend als auch funktional perfekt sind. Von der ersten Skizze über professionelle Fotoshootings bis zum finalen Launch begleiten wir Sie – mit besonderem Fokus auf modernem Webdesign, das auf allen Geräten überzeugt und Ihre Marke zum Leben erweckt.',
    highlight: false,
  },
  {
    icon: TrendingUp,
    title: 'Marketing & Funnel-Performance',
    description: 'Datengetriebene Kampagnen, die konvertieren. Von SEO/SEA über KI-gestützte Suchmaschinenoptimierung bis zur kontinuierlichen Optimierung.',
    features: ['SEO / SEA', 'KI-Suchmaschinen', 'Funnel-Optimierung', 'Performance Marketing', 'A/B Testing'],
    detailedDescription: 'Performance Marketing, das sich rechnet: Wir optimieren Ihre gesamte Customer Journey – von der ersten Interaktion bis zur Conversion. Mit KI-gestützter SEO-Strategie, präzisem Targeting und kontinuierlichem A/B-Testing maximieren wir Ihren ROI. Besonders wichtig: Wir bereiten Sie auch auf die neue Ära der KI-Suchmaschinen (ChatGPT Search, Perplexity) vor, damit Ihr Unternehmen auch dort gefunden wird.',
    highlight: false,
  },
  {
    icon: Database,
    title: 'JTL-Lösungen & Tech Development',
    description: 'Custom Entwicklung und nahtlose JTL-Integration Ihrer Systeme. Von API-Anbindungen bis zu individuellen Softwarelösungen.',
    features: ['JTL-WAWI', 'JTL-Shop', 'System Integration', 'Custom Software', 'API Development'],
    detailedDescription: 'Als JTL-Spezialisten entwickeln wir maßgeschneiderte Lösungen für Ihr E-Commerce-Business. Von der WAWI-Optimierung über Shop-Erweiterungen bis hin zu komplexen Systemintegrationen – wir verbinden Ihre Tools nahtlos miteinander. Dabei kombinieren wir JTL-Expertise mit modernem Tech-Stack und schaffen Workflows, die Ihre Prozesse nicht nur digitalisieren, sondern intelligent automatisieren.',
    highlight: false,
  },
  {
    icon: ShoppingCart,
    title: 'Amazon Begleitung / Beratung',
    description: 'Professionelle Beratung für Ihren Amazon-Erfolg. Von der Account-Optimierung über PPC-Kampagnen bis zur Listing-Optimierung.',
    features: ['Account-Setup', 'Listing-Optimierung', 'PPC-Management', 'Brand Registry', 'SEO für Amazon'],
    detailedDescription: 'Wir begleiten Sie auf Ihrem Weg zum erfolgreichen Amazon-Verkäufer. Unsere Expertise umfasst die komplette Amazon-Strategie: von der initialen Account-Einrichtung über professionelle Produktfotografie und conversion-optimierte Listings bis hin zu datengetriebenem PPC-Management. Wir kennen die Amazon-Algorithmen und wissen, wie Sie Ihre Produkte optimal positionieren, um maximale Sichtbarkeit und Verkäufe zu erzielen.',
    highlight: false,
  },
];

export function Services() {
  const [expandedService, setExpandedService] = useState<number | null>(null);

  const toggleService = (index: number) => {
    setExpandedService(expandedService === index ? null : index);
  };
  return (
    <section id="services" className="relative py-32 bg-black">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl mb-6 text-white">
            Unsere Services
          </h2>
          <p className="text-xl text-white/70 max-w-3xl mx-auto">
            End-to-End Lösungen für digitales Wachstum
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className={service.highlight ? 'md:col-span-2' : ''}
            >
              <motion.div
                whileHover={{ y: -8 }}
                className={`h-full p-8 lg:p-10 rounded-2xl border backdrop-blur-sm group cursor-pointer relative overflow-hidden ${
                  service.highlight
                    ? 'bg-gradient-to-br from-[#C7AB6E]/10 to-[#C7AB6E]/5 border-[#C7AB6E]/30'
                    : 'bg-white/5 border-white/10'
                }`}
              >
                {/* Background glow for highlighted service */}
                {service.highlight && (
                  <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#C7AB6E]/20 rounded-full blur-[100px] group-hover:scale-150 transition-transform duration-700" />
                )}

                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-6">
                    <motion.div
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      className={`w-16 h-16 rounded-xl flex items-center justify-center ${
                        service.highlight
                          ? 'bg-[#C7AB6E]/20'
                          : 'bg-white/10'
                      }`}
                    >
                      <service.icon className={`w-8 h-8 ${
                        service.highlight ? 'text-[#C7AB6E]' : 'text-white'
                      }`} />
                    </motion.div>

                    {service.highlight && (
                      <span className="px-3 py-1 bg-[#C7AB6E]/20 text-[#C7AB6E] text-sm rounded-full border border-[#C7AB6E]/30">
                        Hauptfokus
                      </span>
                    )}
                  </div>

                  <h3 className="text-2xl text-white mb-4">{service.title}</h3>
                  <p className="text-white/70 mb-6 leading-relaxed">{service.description}</p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {service.features.map((feature) => (
                      <span
                        key={feature}
                        className={`px-3 py-1.5 text-sm rounded-lg ${
                          service.highlight
                            ? 'bg-[#C7AB6E]/10 text-[#C7AB6E] border border-[#C7AB6E]/20'
                            : 'bg-white/5 text-white/80 border border-white/10'
                        }`}
                      >
                        {feature}
                      </span>
                    ))}
                  </div>

                  <AnimatePresence>
                    {expandedService === index && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="mb-6 overflow-hidden"
                      >
                        <div className={`p-4 rounded-lg ${
                          service.highlight
                            ? 'bg-[#C7AB6E]/5 border border-[#C7AB6E]/20'
                            : 'bg-white/5 border border-white/10'
                        }`}>
                          <p className="text-white/80 leading-relaxed">
                            {service.detailedDescription}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <motion.button
                    onClick={() => toggleService(index)}
                    whileHover={{ x: 5 }}
                    className={`flex items-center gap-2 transition-colors ${
                      service.highlight
                        ? 'text-[#C7AB6E] hover:text-[#d4b87a]'
                        : 'text-white/70 hover:text-white'
                    }`}
                  >
                    {expandedService === index ? 'Weniger anzeigen' : 'Mehr erfahren'}
                    <motion.div
                      animate={{ rotate: expandedService === index ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </motion.div>
                  </motion.button>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
