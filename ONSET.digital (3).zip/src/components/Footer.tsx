import { motion } from "motion/react";
import {
  Mail,
  Linkedin,
  Twitter,
  Instagram,
  ArrowRight,
} from "lucide-react";
import logo from 'figma:asset/60bb8880c1cd5f2368389d249feeaf0ad6fe9f5d.png';

interface FooterProps {
  onNavigateToPrivacy?: () => void;
  onNavigateToImprint?: () => void;
  onNavigateToTerms?: () => void;
  onNavigateToCareer?: () => void;
}

export function Footer({
  onNavigateToPrivacy,
  onNavigateToImprint,
  onNavigateToTerms,
  onNavigateToCareer,
}: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative bg-black border-t border-white/10">
      {/* CTA Section */}
      <section
        id="contact"
        className="relative py-24 overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-[#C7AB6E]/10 via-transparent to-transparent" />

        <div className="relative z-10 max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full text-[#C7AB6E] text-sm mb-6">
              Bereit zu starten?
            </span>

            <h2 className="text-4xl md:text-6xl text-white mb-6">
              Let's automate your growth
            </h2>

            <p className="text-xl text-white/70 mb-10 max-w-2xl mx-auto">
              Starten Sie jetzt Ihre Bedarfsanalyse und
              erfahren Sie, wie Sie mit uns wachsen
              können
            </p>

            <motion.a
              href="https://www.bedarfsanalyse.onsetdigital.de"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-4 bg-[#C7AB6E] text-black rounded-lg hover:bg-[#d4b87a] transition-colors"
              whileHover={{
                scale: 1.05,
                boxShadow: "0 0 30px rgba(199, 171, 110, 0.6)",
              }}
              whileTap={{ scale: 0.98 }}
            >
              Bedarfsanalyse starten
              <ArrowRight className="w-5 h-5" />
            </motion.a>
          </motion.div>
        </div>
      </section>

      {/* Footer Content */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            {/* Brand */}
            <div>
              <img 
                src={logo} 
                alt="ONSET DIGITAL" 
                className="h-10 w-auto mb-4"
              />
              <p className="text-white/60 text-sm leading-relaxed">
                AI-First Full Service Agency für Automation,
                Branding & skalierbare digitale Systeme
              </p>
            </div>

            {/* Services */}
            <div>
              <h4 className="text-white mb-4">Services</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a
                    href="#services"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    KI-Automation
                  </a>
                </li>
                <li>
                  <a
                    href="#services"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    Branding & Webdesign
                  </a>
                </li>
                <li>
                  <a
                    href="#services"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    Performance Marketing
                  </a>
                </li>
                <li>
                  <a
                    href="#services"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    Tech Development
                  </a>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-white mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a
                    href="#about"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="#clients"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    Kunden
                  </a>
                </li>
                <li>
                  <a
                    href="mailto:info@onsetdigital.de"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    Kontakt
                  </a>
                </li>
                <li>
                  <button
                    onClick={onNavigateToCareer}
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors text-left"
                  >
                    Karriere
                  </button>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-white mb-4">Kontakt</h4>
              <ul className="space-y-2 text-sm mb-6">
                <li>
                  <a
                    href="mailto:info@onsetdigital.de"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    info@onsetdigital.de
                  </a>
                </li>
                <li>
                  <a
                    href="tel:+4922129219740"
                    className="text-white/60 hover:text-[#C7AB6E] transition-colors"
                  >
                    022129219740
                  </a>
                </li>
              </ul>

              <div className="flex gap-3">
                <motion.a
                  href="#"
                  whileHover={{ scale: 1.1, y: -2 }}
                  className="w-10 h-10 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center hover:bg-[#C7AB6E]/20 hover:border-[#C7AB6E]/30 transition-colors"
                >
                  <Linkedin className="w-4 h-4 text-white/70" />
                </motion.a>
                <motion.a
                  href="#"
                  whileHover={{ scale: 1.1, y: -2 }}
                  className="w-10 h-10 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center hover:bg-[#C7AB6E]/20 hover:border-[#C7AB6E]/30 transition-colors"
                >
                  <Twitter className="w-4 h-4 text-white/70" />
                </motion.a>
                <motion.a
                  href="https://www.instagram.com/onset.digital/"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1, y: -2 }}
                  className="w-10 h-10 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center hover:bg-[#C7AB6E]/20 hover:border-[#C7AB6E]/30 transition-colors"
                >
                  <Instagram className="w-4 h-4 text-white/70" />
                </motion.a>
                <motion.a
                  href="mailto:info@onsetdigital.de"
                  whileHover={{ scale: 1.1, y: -2 }}
                  className="w-10 h-10 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center hover:bg-[#C7AB6E]/20 hover:border-[#C7AB6E]/30 transition-colors"
                >
                  <Mail className="w-4 h-4 text-white/70" />
                </motion.a>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/50">
            <p>
              © {currentYear} ONSET DIGITAL. All rights
              reserved.
            </p>
            <div className="flex gap-6">
              <button
                onClick={onNavigateToPrivacy}
                className="hover:text-[#C7AB6E] transition-colors"
              >
                Datenschutz
              </button>
              <button
                onClick={onNavigateToImprint}
                className="hover:text-[#C7AB6E] transition-colors"
              >
                Impressum
              </button>
              <button
                onClick={onNavigateToTerms}
                className="hover:text-[#C7AB6E] transition-colors"
              >
                AGB
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}