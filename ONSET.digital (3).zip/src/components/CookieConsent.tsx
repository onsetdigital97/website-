import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings } from 'lucide-react';

interface CookiePreferences {
  necessary: boolean;
  analytics: boolean;
  marketing: boolean;
}

export function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>({
    necessary: true,
    analytics: false,
    marketing: false,
  });

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAcceptAll = () => {
    const allAccepted: CookiePreferences = {
      necessary: true,
      analytics: true,
      marketing: true,
    };
    localStorage.setItem('cookieConsent', JSON.stringify(allAccepted));
    setIsVisible(false);
  };

  const handleAcceptNecessary = () => {
    const onlyNecessary: CookiePreferences = {
      necessary: true,
      analytics: false,
      marketing: false,
    };
    localStorage.setItem('cookieConsent', JSON.stringify(onlyNecessary));
    setIsVisible(false);
  };

  const handleAcceptSelected = () => {
    localStorage.setItem('cookieConsent', JSON.stringify(preferences));
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="fixed bottom-6 left-6 right-6 md:left-auto md:right-8 md:max-w-xl z-[9999]"
        >
          <div className="bg-black/90 backdrop-blur-md border border-[#C7AB6E]/20 rounded-xl shadow-lg overflow-hidden">
            <div className="p-6">
              {/* Compact Header */}
              <div className="mb-4">
                <p className="text-white/90 mb-2">
                  Wir nutzen Cookies zur Optimierung der Website.
                </p>
                <button
                  onClick={() => setShowDetails(!showDetails)}
                  className="text-[#C7AB6E] text-sm flex items-center gap-1.5 hover:text-[#d4b87a] transition-colors"
                >
                  <Settings className="w-4 h-4" />
                  {showDetails ? 'Weniger anzeigen' : 'Einstellungen anpassen'}
                </button>
              </div>

              {/* Cookie Options (Expandable) */}
              {showDetails && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="space-y-3 mb-4 pb-4 border-b border-white/10"
                >
                  {/* Notwendig */}
                  <label className="flex items-center gap-3 cursor-not-allowed opacity-60">
                    <input
                      type="checkbox"
                      checked={true}
                      disabled
                      className="w-4 h-4 rounded border-2 border-[#C7AB6E]/50 bg-[#C7AB6E]/20"
                    />
                    <span className="text-white text-sm">Notwendig (immer aktiv)</span>
                  </label>

                  {/* Statistik */}
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={preferences.analytics}
                      onChange={(e) =>
                        setPreferences({ ...preferences, analytics: e.target.checked })
                      }
                      className="w-4 h-4 rounded border-2 border-[#C7AB6E]/50 bg-transparent checked:bg-[#C7AB6E] checked:border-[#C7AB6E] transition-all accent-[#C7AB6E]"
                    />
                    <span className="text-white text-sm">Statistik & Analyse</span>
                  </label>

                  {/* Marketing */}
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={preferences.marketing}
                      onChange={(e) =>
                        setPreferences({ ...preferences, marketing: e.target.checked })
                      }
                      className="w-4 h-4 rounded border-2 border-[#C7AB6E]/50 bg-transparent checked:bg-[#C7AB6E] checked:border-[#C7AB6E] transition-all accent-[#C7AB6E]"
                    />
                    <span className="text-white text-sm">Marketing</span>
                  </label>
                </motion.div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleAcceptNecessary}
                  className="flex-1 px-4 py-2.5 bg-white/5 text-white/80 rounded-lg hover:bg-white/10 transition-all border border-white/10"
                >
                  Ablehnen
                </button>
                {showDetails && (
                  <button
                    onClick={handleAcceptSelected}
                    className="flex-1 px-4 py-2.5 bg-[#C7AB6E]/20 text-[#C7AB6E] rounded-lg hover:bg-[#C7AB6E]/30 transition-all border border-[#C7AB6E]/30"
                  >
                    Speichern
                  </button>
                )}
                <button
                  onClick={handleAcceptAll}
                  className="flex-1 px-4 py-2.5 bg-[#C7AB6E] text-black rounded-lg hover:bg-[#d4b87a] transition-all"
                >
                  Akzeptieren
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
