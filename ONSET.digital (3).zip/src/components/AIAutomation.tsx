import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Brain, Zap, Clock, TrendingUp, Bot, Workflow, MessageSquare, Database, Code } from 'lucide-react';

interface AIAutomationProps {
  onNavigateHome: () => void;
}

export function AIAutomation({ onNavigateHome }: AIAutomationProps) {
  const [displayedText, setDisplayedText] = useState('');
  const [currentSection, setCurrentSection] = useState(0);
  const [isTypingComplete, setIsTypingComplete] = useState(false);

  const sections = [
    {
      title: "Was sind KI-Agenten?",
      text: "KI-Agenten sind autonome Software-Systeme, die menschliche Entscheidungen und Handlungen simulieren können. Sie analysieren Daten, treffen intelligente Entscheidungen und führen komplexe Aufgaben selbstständig aus – 24/7, ohne Pause.",
      icon: Brain,
    },
    {
      title: "Wie funktioniert es?",
      text: "Unsere KI-Agenten nutzen fortschrittliche Machine Learning-Algorithmen und Natural Language Processing, um Ihre Geschäftsprozesse zu verstehen, zu lernen und kontinuierlich zu optimieren. Sie integrieren sich nahtlos in Ihre bestehende IT-Infrastruktur.",
      icon: Workflow,
    },
    {
      title: "Intelligente Automatisierung",
      text: "Anders als klassische Automation können KI-Agenten kontextabhängig handeln, aus Erfahrungen lernen und sich an verändernde Bedingungen anpassen. Sie verstehen natürliche Sprache und können komplexe Entscheidungen treffen.",
      icon: Zap,
    },
    {
      title: "Ihr Wettbewerbsvorteil",
      text: "Mit KI-gesteuerten Prozessen steigern Sie nicht nur die Effizienz um bis zu 80%, sondern ermöglichen Ihrem Team, sich auf strategische, wertschöpfende Tätigkeiten zu konzentrieren. Fehlerquoten sinken, während die Kundenzufriedenheit steigt.",
      icon: TrendingUp,
    },
  ];

  const fullText = sections[currentSection]?.text || '';

  useEffect(() => {
    setDisplayedText('');
    setIsTypingComplete(false);
    let currentIndex = 0;

    const typingInterval = setInterval(() => {
      if (currentIndex <= fullText.length) {
        setDisplayedText(fullText.slice(0, currentIndex));
        currentIndex++;
      } else {
        clearInterval(typingInterval);
        setIsTypingComplete(true);
      }
    }, 30);

    return () => clearInterval(typingInterval);
  }, [currentSection, fullText]);

  const handleNext = () => {
    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
    }
  };

  const handlePrevious = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
    }
  };

  const CurrentIcon = sections[currentSection]?.icon || Brain;

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-24">
        {/* Back Button */}
        <motion.button
          onClick={onNavigateHome}
          className="inline-flex items-center gap-2 text-white/60 hover:text-[#C7AB6E] transition-colors mb-12"
          whileHover={{ x: -4 }}
        >
          <ArrowLeft className="w-4 h-4" />
          Zurück zur Startseite
        </motion.button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl mb-4">
            KI-Agenten & Automation
          </h1>
          <p className="text-xl text-white/70">
            Die Zukunft der intelligenten Prozessautomatisierung
          </p>
        </motion.div>

        {/* Typewriter Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-gradient-to-br from-white/5 to-transparent border border-white/10 rounded-3xl p-8 md:p-12 mb-12 backdrop-blur-sm min-h-[400px]"
        >
          {/* Section Title with Icon */}
          <div className="flex items-center gap-4 mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-[#C7AB6E] to-[#d4b87a] rounded-2xl flex items-center justify-center">
              <CurrentIcon className="w-8 h-8 text-black" />
            </div>
            <h2 className="text-3xl md:text-4xl text-white">
              {sections[currentSection]?.title}
            </h2>
          </div>

          {/* Typewriter Text */}
          <div className="relative">
            <p className="text-xl md:text-2xl text-white/80 leading-relaxed min-h-[200px]">
              {displayedText}
              <motion.span
                animate={{ opacity: [1, 0] }}
                transition={{ duration: 0.8, repeat: Infinity }}
                className="inline-block w-1 h-8 bg-[#C7AB6E] ml-1 align-middle"
              />
            </p>
          </div>

          {/* Navigation Dots */}
          <div className="flex justify-center gap-3 mt-12">
            {sections.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSection(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentSection
                    ? 'bg-[#C7AB6E] w-8'
                    : 'bg-white/20 hover:bg-white/40'
                }`}
              />
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            <button
              onClick={handlePrevious}
              disabled={currentSection === 0}
              className={`px-6 py-3 rounded-xl border transition-all ${
                currentSection === 0
                  ? 'border-white/10 text-white/30 cursor-not-allowed'
                  : 'border-[#C7AB6E]/30 text-[#C7AB6E] hover:bg-[#C7AB6E]/10'
              }`}
            >
              Zurück
            </button>
            <button
              onClick={handleNext}
              disabled={currentSection === sections.length - 1}
              className={`px-6 py-3 rounded-xl border transition-all ${
                currentSection === sections.length - 1
                  ? 'border-white/10 text-white/30 cursor-not-allowed'
                  : 'border-[#C7AB6E]/30 text-[#C7AB6E] hover:bg-[#C7AB6E]/10'
              }`}
            >
              Weiter
            </button>
          </div>
        </motion.div>

        {/* Use Cases Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <h2 className="text-3xl md:text-4xl text-center mb-12">
            Einsatzbereiche unserer KI-Agenten
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: MessageSquare,
                title: "Kundenservice",
                description: "24/7 intelligente Chatbots, die komplexe Anfragen verstehen und lösen",
              },
              {
                icon: Database,
                title: "Datenanalyse",
                description: "Automatische Auswertung großer Datenmengen mit KI-gestützten Insights",
              },
              {
                icon: Workflow,
                title: "Prozessoptimierung",
                description: "Intelligente Workflow-Automatisierung über alle Abteilungen hinweg",
              },
              {
                icon: Code,
                title: "Software-Integration",
                description: "Nahtlose Anbindung an bestehende Systeme und APIs",
              },
              {
                icon: Bot,
                title: "Virtuelle Assistenten",
                description: "KI-Assistenten für Vertrieb, Marketing und interne Prozesse",
              },
              {
                icon: Clock,
                title: "Zeitersparnis",
                description: "Automatisierung repetitiver Aufgaben für maximale Effizienz",
              },
            ].map((useCase, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-[#C7AB6E]/30 transition-all group"
              >
                <useCase.icon className="w-10 h-10 text-[#C7AB6E] mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl text-white mb-2">{useCase.title}</h3>
                <p className="text-white/60">{useCase.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="mt-16 bg-gradient-to-br from-[#C7AB6E]/10 to-transparent border border-[#C7AB6E]/30 rounded-3xl p-8 md:p-12 text-center"
        >
          <h2 className="text-3xl md:text-4xl mb-4">
            Bereit für KI-gesteuerte Automation?
          </h2>
          <p className="text-xl text-white/70 mb-8 max-w-2xl mx-auto">
            Lassen Sie uns gemeinsam analysieren, wie KI-Agenten Ihre Geschäftsprozesse revolutionieren können.
          </p>
          <a
            href="mailto:info@onsetdigital.de"
            className="inline-flex items-center gap-2 bg-[#C7AB6E] text-black px-8 py-4 rounded-xl hover:bg-[#d4b87a] transition-all"
          >
            Jetzt Beratung anfragen
            <ArrowLeft className="w-4 h-4 rotate-180" />
          </a>
        </motion.div>
      </div>
    </div>
  );
}
