import { motion } from 'motion/react';
import { Building2 } from 'lucide-react';

interface ImprintProps {
  onNavigateHome: () => void;
}

export function Imprint({ onNavigateHome }: ImprintProps) {
  return (
    <div className="min-h-screen bg-black">
      {/* Content */}
      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          {/* Header Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full mb-6">
              <Building2 className="w-4 h-4 text-[#C7AB6E]" />
              <span className="text-[#C7AB6E] text-sm">Rechtliche Informationen</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl text-white mb-6">
              Impressum
            </h1>
            
            <p className="text-xl text-white/70">
              Angaben gemäß § 5 TMG
            </p>
          </motion.div>

          {/* Content Sections */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-12"
          >
            {/* Section 1 - Company Info */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Angaben gemäß § 5 TMG</h2>
              <div className="text-white/70 space-y-3">
                <div className="pl-4 border-l-2 border-[#C7AB6E]/30">
                  <p className="text-white">Juliane Elmas</p>
                  <p>Marketing Agentur und Reseller</p>
                  <p>Leinsamenweg 64</p>
                  <p>50933 Köln</p>
                </div>
              </div>
            </section>

            {/* Section 2 - Gewerbeanmeldung */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Gewerbeanmeldung</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Die Gewerbeerlaubnis nach §19 Ust. Kleinunternehmer Regelung GewO wurde am 02.09.2024 von folgender Stelle erteilt: Stadt Köln.
                </p>
              </div>
            </section>

            {/* Section 3 - Berufsbezeichnung */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Berufsbezeichnung und berufsrechtliche Regelungen</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  <span className="text-white/90">Berufsbezeichnung:</span> Marketing Agentur
                </p>
                <p>
                  <span className="text-white/90">Verliehen in:</span> Deutschland
                </p>
              </div>
            </section>

            {/* Section 4 - Contact */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Kontakt</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  <span className="text-white/90">Telefon:</span> 022129219740
                </p>
                <p>
                  <span className="text-white/90">E-Mail:</span>{' '}
                  <a href="mailto:info@onsetdigital.de" className="text-[#C7AB6E] hover:underline">
                    info@onsetdigital.de
                  </a>
                </p>
              </div>
            </section>

            {/* Section 5 - Responsible for Content */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Redaktionell verantwortlich</h2>
              <div className="text-white/70 space-y-3">
                <p>ONSET.digital, vertreten durch Juliane Elmas</p>
              </div>
            </section>

            {/* Section 7 - Disclaimer */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Haftungsausschluss</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl text-white mb-3">Haftung für Inhalte</h3>
                  <p className="text-white/70">
                    Die Inhalte unserer Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen. Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl text-white mb-3">Haftung für Links</h3>
                  <p className="text-white/70">
                    Unser Angebot enthält Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl text-white mb-3">Urheberrecht</h3>
                  <p className="text-white/70">
                    Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem deutschen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.
                  </p>
                </div>
              </div>
            </section>

            {/* Section 8 - EU Dispute Resolution */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">EU-Streitschlichtung</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit:
                </p>
                <p>
                  <a 
                    href="https://ec.europa.eu/consumers/odr/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-[#C7AB6E] hover:underline"
                  >
                    https://ec.europa.eu/consumers/odr/
                  </a>
                </p>
                <p className="mt-3">
                  Unsere E-Mail-Adresse finden Sie oben im Impressum.
                </p>
              </div>
            </section>

            {/* Section 9 - Consumer Dispute Resolution */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Verbraucherstreitbeilegung/Universalschlichtungsstelle</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
                </p>
              </div>
            </section>

            {/* Section 10 - DSA Contact Point */}
            <section className="space-y-4">
              <h2 className="text-2xl text-white">Zentrale Kontaktstelle nach dem Digital Services Act - DSA (Verordnung (EU) 2022/265)</h2>
              <div className="text-white/70 space-y-3">
                <p>
                  Unsere zentrale Kontaktstelle für Nutzer und Behörden nach Art. 11, 12 DSA erreichen Sie wie folgt:
                </p>
                <p>
                  <span className="text-white/90">E-Mail:</span>{' '}
                  <a href="mailto:info@onsetdigital.de" className="text-[#C7AB6E] hover:underline">
                    info@onsetdigital.de
                  </a>
                </p>
                <p>
                  <span className="text-white/90">Telefon:</span> 022129219740
                </p>
                <p className="mt-3">
                  Die für den Kontakt zur Verfügung stehenden Sprachen sind: Deutsch, Englisch.
                </p>
              </div>
            </section>

            {/* Last Updated */}
            <div className="pt-8 border-t border-white/10">
              <p className="text-white/50 text-sm">
                Stand: Oktober 2025
              </p>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/50">
            <p>© 2025 ONSET DIGITAL. All rights reserved.</p>
            <div className="flex gap-6">
              <button onClick={onNavigateHome} className="hover:text-[#C7AB6E] transition-colors">
                Zur Startseite
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
