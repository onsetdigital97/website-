import { motion } from "motion/react";
import { ArrowLeft, Briefcase, Rocket, Users } from "lucide-react";
import logo from 'figma:asset/60bb8880c1cd5f2368389d249feeaf0ad6fe9f5d.png';

interface CareerProps {
  onNavigateHome: () => void;
}

export function Career({ onNavigateHome }: CareerProps) {
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-24">
        {/* Back Button */}
        <motion.button
          onClick={onNavigateHome}
          className="inline-flex items-center gap-2 text-white/60 hover:text-[#C7AB6E] transition-colors mb-12"
          whileHover={{ x: -4 }}
        >
          <ArrowLeft className="w-4 h-4" />
          Zurück zur Startseite
        </motion.button>

        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <img 
            src={logo} 
            alt="ONSET DIGITAL" 
            className="h-12 w-auto mx-auto mb-8"
          />
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-center"
        >
          {/* Badge */}
          <span className="inline-block px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full text-[#C7AB6E] text-sm mb-8">
            Werde Teil unseres Teams
          </span>

          {/* Title */}
          <h1 className="text-5xl md:text-7xl mb-6 text-white">
            Coming Soon
          </h1>

          <p className="text-xl text-white/70 mb-16 max-w-2xl mx-auto">
            Unsere Karriereseite ist in Entwicklung. Wir arbeiten an etwas Besonderem und werden bald spannende Möglichkeiten präsentieren.
          </p>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-white/5 border border-white/10 rounded-2xl p-8 backdrop-blur-sm"
            >
              <Rocket className="w-10 h-10 text-[#C7AB6E] mb-4 mx-auto" />
              <h3 className="text-white mb-2">Innovation</h3>
              <p className="text-white/60 text-sm">
                Arbeite mit neuesten Technologien und KI-Lösungen
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="bg-white/5 border border-white/10 rounded-2xl p-8 backdrop-blur-sm"
            >
              <Users className="w-10 h-10 text-[#C7AB6E] mb-4 mx-auto" />
              <h3 className="text-white mb-2">Team Spirit</h3>
              <p className="text-white/60 text-sm">
                Werde Teil eines dynamischen und kreativen Teams
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="bg-white/5 border border-white/10 rounded-2xl p-8 backdrop-blur-sm"
            >
              <Briefcase className="w-10 h-10 text-[#C7AB6E] mb-4 mx-auto" />
              <h3 className="text-white mb-2">Wachstum</h3>
              <p className="text-white/60 text-sm">
                Entwickle dich weiter in einem wachsenden Unternehmen
              </p>
            </motion.div>
          </div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="bg-gradient-to-br from-[#C7AB6E]/10 to-transparent border border-[#C7AB6E]/20 rounded-2xl p-8"
          >
            <p className="text-white/70 mb-4">
              Interessiert? Sende uns deine Initiativbewerbung an:
            </p>
            <a 
              href="mailto:info@onsetdigital.de"
              className="inline-flex items-center gap-2 text-[#C7AB6E] hover:text-[#d4b87a] transition-colors text-lg"
            >
              info@onsetdigital.de
            </a>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
