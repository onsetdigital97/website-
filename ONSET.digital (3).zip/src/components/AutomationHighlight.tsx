import { motion } from 'motion/react';
import { Mail, Users, BarChart3, FileText, Calendar, CheckCircle2, ArrowRight } from 'lucide-react';

interface AutomationHighlightProps {
  onNavigateToAIAutomation?: () => void;
}

const automationProcesses = [
  {
    icon: Mail,
    title: 'Lead-Management',
    description: 'Automatische Erfassung, Qualifizierung und Verteilung von Leads',
  },
  {
    icon: Users,
    title: 'CRM-Automatisierung',
    description: 'Intelligente Kundenbetreuung und Follow-up ohne manuelle Arbeit',
  },
  {
    icon: FileText,
    title: 'Rechnungen & Dokumente',
    description: 'Automatische Erstellung und Versand von Dokumenten',
  },
  {
    icon: BarChart3,
    title: 'Smart Reporting',
    description: 'Automatisierte Datenanalyse und Berichterstattung in Echtzeit',
  },
  {
    icon: Calendar,
    title: 'Social Media Scheduling',
    description: 'Content-Planung und automatische Veröffentlichung',
  },
  {
    icon: CheckCircle2,
    title: 'Workflow-Optimierung',
    description: 'Prozessautomatisierung für maximale Effizienz',
  },
];

export function AutomationHighlight({ onNavigateToAIAutomation }: AutomationHighlightProps = {}) {
  return (
    <section id="automation" className="relative py-32 bg-gradient-to-b from-black via-[#0a0a0a] to-black overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#C7AB6E]/10 rounded-full blur-[150px]" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#C7AB6E]/10 rounded-full blur-[150px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-full text-[#C7AB6E] text-sm mb-6">
            KI-Automatisierung im Fokus
          </span>
          <h2 className="text-4xl md:text-6xl mb-6 text-white">
            Wir ersetzen manuelle Arbeit durch
            <span className="text-[#C7AB6E]"> intelligente Systeme</span>
          </h2>
          <p className="text-xl text-white/70 max-w-3xl mx-auto mb-8">
            Sparen Sie Zeit, reduzieren Sie Fehler und skalieren Sie Ihr Unternehmen mit KI-gesteuerten Automatisierungen
          </p>
          {onNavigateToAIAutomation && (
            <motion.button
              onClick={onNavigateToAIAutomation}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#C7AB6E]/10 border border-[#C7AB6E]/30 rounded-xl text-[#C7AB6E] hover:bg-[#C7AB6E]/20 transition-all"
            >
              Mehr über KI-Agenten erfahren
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          )}
        </motion.div>

        {/* Automation Flow Visualization */}
        <div className="relative mb-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {automationProcesses.map((process, index) => (
              <motion.div
                key={process.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <motion.div
                  whileHover={{ y: -5, scale: 1.02 }}
                  className="relative p-6 bg-gradient-to-br from-white/10 to-white/5 border border-white/10 rounded-xl backdrop-blur-sm group cursor-pointer overflow-hidden"
                >
                  {/* Glow effect on hover */}
                  <div className="absolute inset-0 bg-gradient-to-br from-[#C7AB6E]/0 to-[#C7AB6E]/0 group-hover:from-[#C7AB6E]/10 group-hover:to-[#C7AB6E]/5 transition-all duration-300" />

                  <div className="relative z-10">
                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className="w-12 h-12 bg-[#C7AB6E]/20 rounded-lg flex items-center justify-center mb-4"
                    >
                      <process.icon className="w-6 h-6 text-[#C7AB6E]" />
                    </motion.div>
                    
                    <h3 className="text-lg text-white mb-2">{process.title}</h3>
                    <p className="text-sm text-white/60 leading-relaxed">{process.description}</p>
                  </div>

                  {/* Connection lines for desktop */}
                  {index < automationProcesses.length - 1 && index % 2 !== 1 && (
                    <div className="hidden md:block absolute top-1/2 -right-3 w-6 h-0.5 bg-gradient-to-r from-[#C7AB6E]/50 to-transparent" />
                  )}
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 p-8 lg:p-12 bg-gradient-to-br from-[#C7AB6E]/10 to-[#C7AB6E]/5 border border-[#C7AB6E]/20 rounded-2xl"
        >
          <div className="text-center">
            <div className="text-4xl md:text-5xl text-[#C7AB6E] mb-2">70%</div>
            <p className="text-white/70">Weniger manuelle Arbeit</p>
          </div>
          <div className="text-center border-l border-r border-white/10">
            <div className="text-4xl md:text-5xl text-[#C7AB6E] mb-2">24/7</div>
            <p className="text-white/70">Automatische Prozesse</p>
          </div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl text-[#C7AB6E] mb-2">3x</div>
            <p className="text-white/70">Schnellere Skalierung</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
