import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import logo from 'figma:asset/60bb8880c1cd5f2368389d249feeaf0ad6fe9f5d.png';

interface NavigationProps {
  onNavigateToSupport?: () => void;
  onNavigateToKIAudit?: () => void;
  onNavigateHome?: () => void;
  onNavigateToServices?: () => void;
  onNavigateToAbout?: () => void;
  onNavigateToAutomation?: () => void;
}

export function Navigation({ onNavigateToSupport, onNavigateToKIAudit, onNavigateHome, onNavigateToServices, onNavigateToAbout, onNavigateToAutomation }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', onClick: onNavigateHome },
    { label: 'Services', onClick: onNavigateToServices },
    { label: 'AI Automation', onClick: onNavigateToAutomation },
    { label: 'Support-Pakete', onClick: onNavigateToSupport },
    { label: 'About', onClick: onNavigateToAbout },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-black/80 backdrop-blur-xl border-b border-[#C7AB6E]/20' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <motion.button
            onClick={onNavigateHome}
            className="relative z-10"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.2 }}
          >
            <img 
              src={logo} 
              alt="ONSET DIGITAL" 
              className="h-10 md:h-12 w-auto"
            />
          </motion.button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              item.onClick ? (
                <button
                  key={item.label}
                  onClick={item.onClick}
                  className="relative text-white/80 hover:text-white transition-colors group"
                >
                  {item.label}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#C7AB6E] group-hover:w-full transition-all duration-300" />
                </button>
              ) : (
                <a
                  key={item.label}
                  href={item.href}
                  {...(item.external && { target: '_blank', rel: 'noopener noreferrer' })}
                  className="relative text-white/80 hover:text-white transition-colors group"
                >
                  {item.label}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#C7AB6E] group-hover:w-full transition-all duration-300" />
                </a>
              )
            ))}
            <motion.a
              href="https://www.bedarfsanalyse.onsetdigital.de"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2.5 bg-[#C7AB6E] text-black rounded-lg hover:bg-[#d4b87a] transition-colors"
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(199, 171, 110, 0.5)' }}
              whileTap={{ scale: 0.98 }}
            >
              Bedarfsanalyse
            </motion.a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden text-white z-10"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-black/95 backdrop-blur-xl border-b border-[#C7AB6E]/20"
          >
            <div className="px-6 py-6 space-y-4">
              {navItems.map((item) => (
                item.onClick ? (
                  <button
                    key={item.label}
                    onClick={() => {
                      item.onClick?.();
                      setIsMobileMenuOpen(false);
                    }}
                    className="block w-full text-left text-white/80 hover:text-white transition-colors py-2"
                  >
                    {item.label}
                  </button>
                ) : (
                  <a
                    key={item.label}
                    href={item.href}
                    {...(item.external && { target: '_blank', rel: 'noopener noreferrer' })}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block text-white/80 hover:text-white transition-colors py-2"
                  >
                    {item.label}
                  </a>
                )
              ))}
              <a
                href="https://www.bedarfsanalyse.onsetdigital.de"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block w-full px-6 py-3 bg-[#C7AB6E] text-black rounded-lg text-center hover:bg-[#d4b87a] transition-colors"
              >
                Bedarfsanalyse
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
