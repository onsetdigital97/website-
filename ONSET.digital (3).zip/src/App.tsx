import { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { WhyUs } from './components/WhyUs';
import { Services } from './components/Services';
import { AutomationHighlight } from './components/AutomationHighlight';
import { Clients } from './components/Clients';
import { Footer } from './components/Footer';
import { Privacy } from './components/Privacy';
import { Imprint } from './components/Imprint';
import { Terms } from './components/Terms';
import { SupportPackages } from './components/SupportPackages';
import { KIAudit } from './components/KIAudit';
import { Career } from './components/Career';
import { AIAutomation } from './components/AIAutomation';
import { About } from './components/About';
import { CookieConsent } from './components/CookieConsent';
import { Toaster } from './components/ui/sonner';

type Page = 'home' | 'privacy' | 'imprint' | 'terms' | 'support' | 'ki-audit' | 'career' | 'ai-automation' | 'about';

// Helper to get page from URL path
const getPageFromPath = (): Page => {
  const path = window.location.pathname.replace(/^\/|\/$/g, '');
  
  const pageMap: Record<string, Page> = {
    '': 'home',
    'about': 'about',
    'privacy': 'privacy',
    'imprint': 'imprint',
    'terms': 'terms',
    'support': 'support',
    'ki-audit': 'ki-audit',
    'career': 'career',
    'ai-automation': 'ai-automation',
  };
  
  return pageMap[path] || 'home';
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>(getPageFromPath());

  // Update URL when page changes
  const navigateToPage = (page: Page) => {
    const pathMap: Record<Page, string> = {
      'home': '/',
      'about': '/about',
      'privacy': '/privacy',
      'imprint': '/imprint',
      'terms': '/terms',
      'support': '/support',
      'ki-audit': '/ki-audit',
      'career': '/career',
      'ai-automation': '/ai-automation',
    };
    
    const path = pathMap[page];
    window.history.pushState({}, '', path);
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  // Handle browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPage(getPageFromPath());
      window.scrollTo(0, 0);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const scrollToSection = (sectionId: string) => {
    setTimeout(() => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const handleNavigateToServices = () => {
    navigateToPage('home');
    scrollToSection('services');
  };

  const handleNavigateToAbout = () => {
    navigateToPage('about');
  };

  const handleNavigateToAutomation = () => {
    navigateToPage('ai-automation');
  };

  if (currentPage === 'privacy') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <Privacy onNavigateHome={() => navigateToPage('home')} />
      </div>
    );
  }

  if (currentPage === 'imprint') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <Imprint onNavigateHome={() => navigateToPage('home')} />
      </div>
    );
  }

  if (currentPage === 'terms') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <Terms onNavigateHome={() => navigateToPage('home')} />
      </div>
    );
  }

  if (currentPage === 'support') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <SupportPackages 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToPrivacy={() => navigateToPage('privacy')}
          onNavigateToImprint={() => navigateToPage('imprint')}
          onNavigateToTerms={() => navigateToPage('terms')}
        />
      </div>
    );
  }

  if (currentPage === 'ki-audit') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <KIAudit onNavigateHome={() => navigateToPage('home')} />
      </div>
    );
  }

  if (currentPage === 'career') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <Career onNavigateHome={() => navigateToPage('home')} />
      </div>
    );
  }

  if (currentPage === 'ai-automation') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <AIAutomation onNavigateHome={() => navigateToPage('home')} />
        <Footer 
          onNavigateToPrivacy={() => navigateToPage('privacy')}
          onNavigateToImprint={() => navigateToPage('imprint')}
          onNavigateToTerms={() => navigateToPage('terms')}
          onNavigateToCareer={() => navigateToPage('career')}
        />
        <CookieConsent />
        <Toaster theme="dark" position="bottom-right" />
      </div>
    );
  }

  if (currentPage === 'about') {
    return (
      <div className="size-full bg-black">
        <Navigation 
          onNavigateHome={() => navigateToPage('home')}
          onNavigateToSupport={() => navigateToPage('support')}
          onNavigateToKIAudit={() => navigateToPage('ki-audit')}
          onNavigateToServices={handleNavigateToServices}
          onNavigateToAbout={handleNavigateToAbout}
          onNavigateToAutomation={handleNavigateToAutomation}
        />
        <About onNavigateHome={() => navigateToPage('home')} />
        <Footer 
          onNavigateToPrivacy={() => navigateToPage('privacy')}
          onNavigateToImprint={() => navigateToPage('imprint')}
          onNavigateToTerms={() => navigateToPage('terms')}
          onNavigateToCareer={() => navigateToPage('career')}
        />
        <CookieConsent />
        <Toaster theme="dark" position="bottom-right" />
      </div>
    );
  }

  return (
    <div className="size-full bg-black">
      <Navigation 
        onNavigateHome={() => navigateToPage('home')}
        onNavigateToSupport={() => navigateToPage('support')}
        onNavigateToKIAudit={() => navigateToPage('ki-audit')}
        onNavigateToServices={handleNavigateToServices}
        onNavigateToAbout={handleNavigateToAbout}
        onNavigateToAutomation={handleNavigateToAutomation}
      />
      <main>
        <Hero onNavigateToKIAudit={() => navigateToPage('ki-audit')} />
        <WhyUs />
        <Services />
        <AutomationHighlight onNavigateToAIAutomation={() => navigateToPage('ai-automation')} />
        <Clients />
      </main>
      <Footer 
        onNavigateToPrivacy={() => navigateToPage('privacy')}
        onNavigateToImprint={() => navigateToPage('imprint')}
        onNavigateToTerms={() => navigateToPage('terms')}
        onNavigateToCareer={() => navigateToPage('career')}
      />
      <CookieConsent />
      <Toaster theme="dark" position="bottom-right" />
    </div>
  );
}
